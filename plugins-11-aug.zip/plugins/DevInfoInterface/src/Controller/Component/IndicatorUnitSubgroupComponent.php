<?php

namespace DevInfoInterface\Controller\Component;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;

/**
 * IndicatorUnitSubgroup Component
 */
class IndicatorUnitSubgroupComponent extends Component {

    // The other component your component uses
    public $components = [
        'DevInfoInterface.Data', 'DevInfoInterface.Indicator',
        'DevInfoInterface.Unit',
        'DevInfoInterface.SubgroupVals',
        'DevInfoInterface.CommonInterface'
        ];
	
    public $delm ='{-}'; 	
    public $IndicatorUnitSubgroupObj = NULL;

    public function initialize(array $config) {
        parent::initialize($config);
        $this->IndicatorUnitSubgroupObj = TableRegistry::get('DevInfoInterface.IndicatorUnitSubgroup');
    }

    /**
     * Get records based on conditions
     * 
     * @param array $fields The Fields to SELECT from the Query. {DEFAULT : empty}
     * @param array $conditions The WHERE conditions for the Query. {DEFAULT : empty}
     * @param string $type query type
     * @return array fetched records
     */
    public function getRecords(array $fields, array $conditions, $type = 'all') {
        //return $this->IndicatorUnitSubgroupObj->getRecords($fields, $conditions, $type);
        
        // MSSQL Compatibilty - MSSQL can't support more than 2100 params - 900 to be safe
        $chunkSize = 900;

        if (isset($conditions['OR']) && count($conditions['OR'], true) > $chunkSize) {

            $result = [];
            $countIncludingChildparams = count($conditions['OR'], true);

            // count for single index
            //$orSingleParamCount = count(reset($conditions['OR']));
            
            //$splitChunkSize = floor(count($conditions['OR']) / $orSingleParamCount);
            $splitChunkSize = floor(count($conditions['OR']) / ($countIncludingChildparams / $chunkSize));

            // MSSQL Compatibilty - MSSQL can't support more than 2100 params
            $orConditionsChunked = array_chunk($conditions['OR'], $splitChunkSize);

            foreach ($orConditionsChunked as $orCond) {
                $conditions['OR'] = $orCond;
                $getIus = $this->IndicatorUnitSubgroupObj->getRecords($fields, $conditions, $type);
                // We want to preserve the keys in list, as there will always be Nid in keys
                if ($type == 'list') {
                    $result = array_replace($result, $getIus);
                }// we dont need to preserve keys, just merge
                else {
                    $result = array_merge($result, $getIus);
                }
            }
        } else {
            $result = $this->IndicatorUnitSubgroupObj->getRecords($fields, $conditions, $type);
        }
        return $result;
        
    }

    /**
     * getGroupedList method
     *
     * @param array $conditions Conditions on which to search. {DEFAULT : empty}
     * @param array $fields Fields to fetch. {DEFAULT : empty}
     * @return void
     */
    public function getGroupedList(array $fields, array $conditions) {
        return $this->IndicatorUnitSubgroupObj->getGroupedList($fields, $conditions);
    }

    /**
     * deleteRecords method
     *
     * @param array $conditions Fields to fetch. {DEFAULT : empty}
     * @return void
     */
    public function deleteRecords($conditions = []) {
        return $this->IndicatorUnitSubgroupObj->deleteRecords($conditions);
    }

    /**
     * insertData method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function insertData($fieldsArray = []) {
        return $this->IndicatorUnitSubgroupObj->insertData($fieldsArray);
    }

    /**
     * Insert multiple rows at once
     *
     * @param array $dataArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function insertOrUpdateBulkData($dataArray = []) {
        return $this->IndicatorUnitSubgroupObj->insertOrUpdateBulkData($dataArray);
    }

    /**
     * updateRecords method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function updateRecords($fieldsArray = [], $conditions = []) {
        return $this->IndicatorUnitSubgroupObj->updateRecords($fieldsArray, $conditions);
    }
    
    /**
     * getConcatedFields method
     * @param array $conditions The WHERE conditions for the Query. {DEFAULT : empty}
     * @param array $fields The Fields to SELECT from the Query. {DEFAULT : empty}
     * @return void
     */
    public function getConcatedFields(array $fields, array $conditions, $type = null)
    {
        if($type == 'list' && array_key_exists(2, $fields)){
            $result = $this->IndicatorUnitSubgroupObj->getConcatedFields($fields, $conditions, 'all');
            if(!empty($result)){
                return array_column($result, 'concatinated', $fields[2]);
            }else{
                return [];
            }
        }else{
            return $this->IndicatorUnitSubgroupObj->getConcatedFields($fields, $conditions, $type);
        }
    }
    
    /**
     * getConcatedIus method
     * @param array $conditions The WHERE conditions for the Query. {DEFAULT : empty}
     * @param array $fields The Fields to SELECT from the Query. {DEFAULT : empty}
     * @return void
     */
    public function getConcatedIus(array $fields, array $conditions, $type = null)
    {
        // MSSQL Compatibilty - MSSQL can't support more than 2100 params - 900 to be safe
        $chunkSize = 900;
        
        if(isset($conditions['OR']) && count($conditions['OR'], true) > $chunkSize){
      
            $result = [];
            
            // count for single index
            $orSingleParamCount = count(reset($conditions['OR']));
            $splitChunkSize = floor(count($conditions['OR'])/$orSingleParamCount);
            
            // MSSQL Compatibilty - MSSQL can't support more than 2100 params
            $orConditionsChunked = array_chunk($conditions['OR'], $splitChunkSize);
            
            foreach($orConditionsChunked as $orCond){
                $conditions['OR'] = $orCond;
                $getConcatedIus = $this->IndicatorUnitSubgroupObj->getConcatedIus($fields, $conditions, 'all');
                $result = array_merge($result, $getConcatedIus);
            }
        }else{
            $result = $this->IndicatorUnitSubgroupObj->getConcatedIus($fields, $conditions, 'all');
        }
        
        if($type == 'list'){            
            if(!empty($result)){
                $result = array_column($result, 'concatinated', _IUS_IUSNID);
            }
        }

        return $result;
    }

    /**
     * getAllIUConcatinated method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function getAllIUConcatinated($fields = [], $conditions = [], $extra = []) {
        
        $result = $this->IndicatorUnitSubgroupObj->getAllIUConcatinated($fields, $conditions, $extra);
        if(isset($extra['type']) && $extra['type'] == 'list'){   
            if(!empty($result)){
                $result = array_column($result, 'concatinated', _IUS_IUSNID);
                if(isset($extra['unique']) && $extra['unique'] == true){
                    $result = array_unique($result);
                }
            }
        }else{
            if(isset($extra['unique']) && $extra['unique'] == true){
                $result = array_intersect_key($result, array_unique(array_column($result, 'concatinated')));
            }
        }
        return $result;
    }

    /**
     * getAllIU method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function getAllIU($fields = [], $conditions = [], $extra = []) {
        
        if(isset($extra['indicatorGidsAccessible'])){
            $getIndicatorNidsFromGids = $this->Indicator->getRecords([_INDICATOR_INDICATOR_NID, _INDICATOR_INDICATOR_NID], [_INDICATOR_INDICATOR_GID.' IN' => $extra['indicatorGidsAccessible']], 'list');
            $conditions[_IUS_INDICATOR_NID . ' IN'] = $getIndicatorNidsFromGids;
        }        
        //Get IU Nids list
        $result = $this->getAllIUConcatinated($fields, $conditions, $extra);
        
        //Get Indicator Details From Nid
        $IndicatorField[0] = _INDICATOR_INDICATOR_NID;
        $IndicatorField[1] = _INDICATOR_INDICATOR_GID;
        $IndicatorField[2] = _INDICATOR_INDICATOR_NAME;
        $IndicatorCondition = [_INDICATOR_INDICATOR_NID . ' IN' => array_unique(array_column($result, _INDICATOR_INDICATOR_NID))];
        $IndicatorGidList = $this->Indicator->getRecords($IndicatorField, $IndicatorCondition, 'all');
        $IndicatorGidList = array_combine(array_column($IndicatorGidList, _INDICATOR_INDICATOR_NID), $IndicatorGidList);
        
        //Get Unit Details From Nid
        $unitField[0] = _UNIT_UNIT_NID;
        $unitField[1] = _UNIT_UNIT_GID;
        $unitField[2] = _UNIT_UNIT_NAME;
        $unitCondition = [_UNIT_UNIT_NID . ' IN' => array_unique(array_column($result, _UNIT_UNIT_NID))];
        $unitGidList = $this->Unit->getRecords($unitField, $unitCondition, 'all');
        $unitGidList = array_combine(array_column($unitGidList, _UNIT_UNIT_NID), $unitGidList);
        
        //Get SubgroupVals Details From Nid
        $subgroupValsField[0] = _SUBGROUP_VAL_SUBGROUP_VAL_NID;
        $subgroupValsField[1] = _SUBGROUP_VAL_SUBGROUP_VAL_GID;
        $subgroupValsField[2] = _SUBGROUP_VAL_SUBGROUP_VAL;
        $subgroupValsCondition = [_SUBGROUP_VAL_SUBGROUP_VAL_NID . ' IN' => array_unique(array_column($result, _SUBGROUP_VAL_SUBGROUP_VAL_NID))];
        $subgroupValsGidList = $this->SubgroupVals->getRecords($subgroupValsField, $subgroupValsCondition, 'all');
        $subgroupValsGidList = array_combine(array_column($subgroupValsGidList, _SUBGROUP_VAL_SUBGROUP_VAL_NID), $subgroupValsGidList);
        
        $preparedData = [];
        if($extra['onDemand'] == true){
            $childExists = true;
            $nodes = [];
        }else{
            $childExists = false;
        }
        
        foreach($result as $key => $value){
            
            if(!isset($IndicatorGidList[$value[_INDICATOR_INDICATOR_NID]]) || !isset($unitGidList[$value[_UNIT_UNIT_NID]])) {
                continue;
            }
            
            if($extra['onDemand'] == true){
                $preparedData[$value[_INDICATOR_INDICATOR_NID] . '_' . $value[_UNIT_UNIT_NID]] = [
                    'iGid' => $IndicatorGidList[$value[_INDICATOR_INDICATOR_NID]][_INDICATOR_INDICATOR_GID],
                    'iNid' => $value[_INDICATOR_INDICATOR_NID],
                    'uGid' => $unitGidList[$value[_UNIT_UNIT_NID]][_UNIT_UNIT_GID],
                    'uNid' => $value[_UNIT_UNIT_NID],
                    'iName' => $IndicatorGidList[$value[_INDICATOR_INDICATOR_NID]][_INDICATOR_INDICATOR_NAME],
                    'uName' => $unitGidList[$value[_UNIT_UNIT_NID]][_UNIT_UNIT_NAME],
                    'childExists' => true,
                    'nodes' => []
                ];
            }else{            
                // Prepare Subgroup Node
                $subGroupNode = [
                        _IUS_IUSNID => $value[_IUS_IUSNID],
                        'iusGid' => $value[_INDICATOR_INDICATOR_NID] . '{~}' . $value[_UNIT_UNIT_NID] . '{~}' . $subgroupValsGidList[$value[_SUBGROUP_VAL_SUBGROUP_VAL_NID]][_SUBGROUP_VAL_SUBGROUP_VAL_GID],
                        'iusNid' => $value[_INDICATOR_INDICATOR_NID] . '{~}' . $value[_UNIT_UNIT_NID] . '{~}' . $value[_SUBGROUP_VAL_SUBGROUP_VAL_NID],
                        'sName' => $subgroupValsGidList[$value[_SUBGROUP_VAL_SUBGROUP_VAL_NID]][_SUBGROUP_VAL_SUBGROUP_VAL],
                        'childExists' => false,
                        'nodes' => []
                    ];

                // Attach Subgroup to IU Node
                if(array_key_exists($value[_INDICATOR_INDICATOR_NID] . '_' . $value[_UNIT_UNIT_NID], $preparedData)){
                    $preparedData[$value[_INDICATOR_INDICATOR_NID] . '_' . $value[_UNIT_UNIT_NID]]['nodes'][] = $subGroupNode;
                }else{
                    $preparedData[$value[_INDICATOR_INDICATOR_NID] . '_' . $value[_UNIT_UNIT_NID]] = [
                        'iGid' => $IndicatorGidList[$value[_INDICATOR_INDICATOR_NID]][_INDICATOR_INDICATOR_GID],
                        'iNid' => $value[_INDICATOR_INDICATOR_NID],
                        'uGid' => $unitGidList[$value[_UNIT_UNIT_NID]][_UNIT_UNIT_GID],
                        'uNid' => $value[_UNIT_UNIT_NID],
                        'iName' => $IndicatorGidList[$value[_INDICATOR_INDICATOR_NID]][_INDICATOR_INDICATOR_NAME],
                        'uName' => $unitGidList[$value[_UNIT_UNIT_NID]][_UNIT_UNIT_NAME],
                        'childExists' => true,
                        'nodes' => [$subGroupNode]
                    ];
                }
            }
        }
        
        return $preparedData;
    }

    /**
     * getAllSubgroupsFromIUGids method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function getAllSubgroupsFromIUGids($fields = [], $conditions = [], $extra = []) {
        
        //Get Indicator Details From Gid
        $IndicatorField[0] = _INDICATOR_INDICATOR_NID;
        $IndicatorCondition = [_INDICATOR_INDICATOR_GID . ' IN' => $conditions['iGid']];
        $IndicatorGidList = $this->Indicator->getRecords($IndicatorField, $IndicatorCondition, 'all');
        
        //Get Unit Details From Gid
        $unitField[0] = _UNIT_UNIT_NID;
        $unitCondition = [_UNIT_UNIT_GID . ' IN' => $conditions['uGid']];
        $unitGidList = $this->Unit->getRecords($unitField, $unitCondition, 'all');
        
        //Get Unit Details From Gid
        $IusField = [_IUS_IUSNID, _IUS_SUBGROUP_VAL_NID];
        $IusCondition = [_IUS_INDICATOR_NID => $IndicatorGidList[0][_INDICATOR_INDICATOR_NID] , _IUS_UNIT_NID => $unitGidList[0][_UNIT_UNIT_NID]];
        $IusList = $this->getRecords($IusField, $IusCondition, 'list');
        
        //Get Subgroup Details From Nid
        $subgroupField = [_SUBGROUP_VAL_SUBGROUP_VAL_NID, 'sName' => _SUBGROUP_VAL_SUBGROUP_VAL, 'sGid' => _SUBGROUP_VAL_SUBGROUP_VAL_GID];
        $subgroupCondition = [_SUBGROUP_VAL_SUBGROUP_VAL_NID . ' IN' => $IusList];
        $subgroupList = $this->SubgroupVals->getRecords($subgroupField, $subgroupCondition, 'all');
        
        foreach($subgroupList as $key => &$value){
            $value = [
                    _IUS_IUSNID => array_search($value[_SUBGROUP_VAL_SUBGROUP_VAL_NID], $IusList),
                    'iusGid' => $conditions['iGid'] . '{~}' . $conditions['uGid'] . '{~}' . $value['sGid'],
                    'sName' => $value['sName'],
                    'childExists' => false,
                    'nodes' => []
                ];
        }
        
        return $subgroupList;
    }
    

    /**
     * getAllSubgroupsFromIUGids method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function getIusNameAndGids($conditions = [], $extra = []) {
        
        //Get Indicator Details From Gid
        $IndicatorField = [_INDICATOR_INDICATOR_NID, _INDICATOR_INDICATOR_NAME];
        $IndicatorCondition = [_INDICATOR_INDICATOR_GID => $conditions['iGid']];
        $IndicatorGidList = $this->Indicator->getRecords($IndicatorField, $IndicatorCondition, 'all');
        
        if(!isset($IndicatorGidList[0])) return ['error' => _INDICATOR_IS_EMPTY];
        
        //Get Unit Details From Gid
        $unitField = [_UNIT_UNIT_NID, _UNIT_UNIT_NAME];
        $unitCondition = [_UNIT_UNIT_GID => $conditions['uGid']];
        $unitGidList = $this->Unit->getRecords($unitField, $unitCondition, 'all');
        
        if(!isset($unitGidList[0])) return ['error' => _UNIT_IS_EMPTY];
        
        if(isset($conditions['sGid']) && !empty($conditions['sGid'])){
            //Get Subgroup Details From GId
            $subgroupField = [_SUBGROUP_VAL_SUBGROUP_VAL_NID, 'sName' => _SUBGROUP_VAL_SUBGROUP_VAL, 'sGid' => _SUBGROUP_VAL_SUBGROUP_VAL_GID];
            $subgroupCondition = [_SUBGROUP_VAL_SUBGROUP_VAL_GID => $conditions['sGid']];
            $subgroupList = $this->SubgroupVals->getRecords($subgroupField, $subgroupCondition, 'all');
            
        }else{
            //Get Unit Details From Gid
            $IusField = [_IUS_IUSNID, _IUS_SUBGROUP_VAL_NID, _IUS_ISDEFAULTSUBGROUP];
            $IusCondition = [_IUS_INDICATOR_NID => $IndicatorGidList[0][_INDICATOR_INDICATOR_NID] , _IUS_UNIT_NID => $unitGidList[0][_UNIT_UNIT_NID]];
            $IusResult = $this->getRecords($IusField, $IusCondition, 'all');
            $IusList = array_column($IusResult, _IUS_ISDEFAULTSUBGROUP);
            
            if(array_search(true, $IusList)){
                $sNid = $IusResult[array_search(true, $IusList)][_IUS_SUBGROUP_VAL_NID];
            }else{
                $sNid = $IusResult[array_search(false, $IusList)][_IUS_SUBGROUP_VAL_NID];
            }
            
            //Get Subgroup Details From Nid
            $subgroupField = [_SUBGROUP_VAL_SUBGROUP_VAL_NID, 'sName' => _SUBGROUP_VAL_SUBGROUP_VAL, 'sGid' => _SUBGROUP_VAL_SUBGROUP_VAL_GID];
            $subgroupCondition = [_SUBGROUP_VAL_SUBGROUP_VAL_NID => $sNid];
            $subgroupList = $this->SubgroupVals->getRecords($subgroupField, $subgroupCondition, 'all');
        }

        if(!empty($subgroupList)){
            $return = [
                'iGid' => $conditions['iGid'],
                'iName' => $IndicatorGidList[0][_INDICATOR_INDICATOR_NAME],
                'uGid' => $conditions['uGid'],
                'uName' => $unitGidList[0][_UNIT_UNIT_NAME],
                'sGid' => $subgroupList[0]['sGid'],
                'sName' => $subgroupList[0]['sName'],
                'iusGid' => $conditions['iGid'] . '{~}' . $conditions['uGid'] . '{~}' . $subgroupList[0]['sGid'],
            ];
        }else{
            return ['error' => _SUBGROUP_IS_EMPTY];
        }
        return $return;
    }

    /**
     * testCasesFromTable method
     *
     * @param array $fieldsArray Fields to insert with their Data. {DEFAULT : empty}
     * @return void
     */
    public function testCasesFromTable($params = []) {
        return $this->IndicatorUnitSubgroupObj->testCasesFromTable($params);
    }
	
	
    /*
     *
     * get all ius details or iu details on basis of ind gid,unit gid and subgrp gid 
     * @iGid indicator gid 
     * @uGid  unit gid 
     * @sGid subgroup val gid
     * return the iusnid details with ind,unit and subgrp details .	 
    */

    public function getIusNidsDetails($iGid='', $uGid='', $sGid='') {
        return $iusData = $this->IndicatorUnitSubgroupObj->getIusNidsDetails($iGid, $uGid, $sGid);
    }
	
	/*
    * get the indicator details on basis of ius nids 
    * @iusNids is the iusnids 
    * return the indicator details 
    */
    public function getIndicatorDetails($iusNids = []) {
        return $indData = $this->IndicatorUnitSubgroupObj->getIndicatorDetails($iusNids);
    }
	
	/*
    * get the indicator,Unit,Subgroup  details on basis of ius nids 
    * @iusNid is the iusnid 
    * return array
    */
    public function getIUSDetails($iusNid ='') {
        return $iusData = $this->IndicatorUnitSubgroupObj->getIUSDetails($iusNid);
    }
	
	
	/*
    * get the indicator,Unit,Subgroup  details on basis of ius nids 
    * @iusNid is the iusnid 
    * return array
    */
    public function getIndicatorSpecificUSDetails($indNid =[],$uNid=[]) {

        return $iusData = $this->IndicatorUnitSubgroupObj->getIndicatorSpecificUSDetails($indNid,$uNid);
    }
	

    


}
