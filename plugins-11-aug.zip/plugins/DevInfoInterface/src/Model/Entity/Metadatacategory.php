<?php
namespace DevInfoInterface\Model\Entity;

use Cake\ORM\Entity;

/**
 * Metadata category Model
 */
class Metadatacategory extends Entity
{

   protected $_accessible = ['*' => true];
    
}