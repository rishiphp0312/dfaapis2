<?php

namespace DevInfoInterface\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
