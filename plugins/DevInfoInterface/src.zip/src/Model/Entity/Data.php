<?php
namespace DevInfoInterface\Model\Entity;

use Cake\ORM\Entity;

/**
 * Data Entity.
 */
class Data extends Entity
{

        protected $_accessible = ['*' => true];

}
