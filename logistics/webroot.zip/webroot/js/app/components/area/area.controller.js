angular.module('logistics.area')
.controller('areaMgtCtrl', ['$scope', '$state', '$rootScope', 'areaService', 'errorService', '$stateParams', '$filter', 'modalService', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, areaService, errorService, $stateParams, $filter, modalService, PAGINATION_DEFAULT) {

    $rootScope.shipmentId = '';

    $scope.showExportLoader = false;

    $scope.exportUrl = '';

    $scope.showExportUrl = false;

    $scope.isProcessing = false;

    $scope.tabs = [{
        id: 'areaLevel',
        title: 'Area Levels'
    }, {
        id: 'areaName',
        title: 'Area Names '
    }];

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    $scope.openAddModify = function () {
        if ($scope.tabs[0].active == true) {
            $state.go('logistics.home.areaMgt.addLevel');
        }
        else {
            $state.go('logistics.home.areaMgt.addName');
        }
    }

    //get list of area levels
    areaService.getAreaLevelList().then(function (data) {
        $scope.areaLevelList = data.levelList;
        $scope.showNoRecordMsg = $scope.areaLevelList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    //get list of area names
    areaService.getAreaNamesList().then(function (data) {
        $scope.areaNameList = data.areaList;
        $scope.showNoRecordMsg = data.areaList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deleteArea = function (area) {

        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Areas',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {

            if ($scope.tabs[0].active == true) {

                areaService.deleteAreaLevel({ levelId: area.id }).then(function (res) {
                    $scope.areaLevelList = $filter('filter')($scope.areaLevelList, { id: ('!' + area.id) });
                    $scope.showDeleteSucessMsg = true;
                    $scope.paginationChanged();
                }, function (err) {
                    errorService.show(err);
                });
            } else {
                areaService.deleteAreaName({ areaId: area.id }).then(function (res) {
                    $scope.areaNameList = $filter('filter')($scope.areaNameList, { id: ('!' + area.id) });
                    $scope.showDeleteSucessMsg = true;
                    $scope.paginationChanged();

                }, function (err) {
                    errorService.show(err);
                });
            }

        });
    }

    $scope.export = function () {

        $scope.showExportLoader = true;

        $scope.isProcessing = true;

        areaService.export().then(function (res) {

            $scope.showExportUrl = true;
            $scope.showExportLoader = false;
            $scope.isProcessing = false;
            $scope.exportUrl = res.data.areaExport;

        }, function (err) {
            $scope.showExportLoader = false;
            $scope.isProcessing = false;
            errorService.show(err);
        })

    }

    $scope.tabSelected = function (tab) {
    
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }

} ])

.controller('addModifyLevelCtrl', ['$scope', '$state', '$rootScope', 'areaService', 'errorService', '$stateParams', 'onSuccessDialogService', 'commonService', 'STATUS_OPTIONS',
function ($scope, $state, $rootScope, areaService, errorService, $stateParams, onSuccessDialogService, commonService, STATUS_OPTIONS) {

    $scope.isModify = $stateParams.id ? true : false;

    if ($scope.isModify) {
        areaService.getAreaLevelDetails({ levelId: $stateParams.id })
        .then(function (data) {
            $scope.areaLevel = data.levelDetails;
        })
    } else {
        $scope.areaLevel = '';
    }

    $scope.statusOptions = angular.copy(STATUS_OPTIONS);

    $scope.saveAreaLevel = function (areaLevel) {

        var msg = $scope.isModify ? 'Area level updated successfully.' : 'Area level added successfully.';

        areaService.addModifyLevel(areaLevel)
        .then(function (res) {
            onSuccessDialogService.show(msg, function () {

                $state.go('logistics.home.areaMgt');
            })
        }, function (err) {
            commonService.error.show(err);
        });
    }

} ])

.controller('addModifyNameCtrl', ['$scope', '$state', '$rootScope', 'areaService', 'errorService', '$stateParams', 'onSuccessDialogService', 'filtersService', 'commonService', 'STATUS_OPTIONS',
function ($scope, $state, $rootScope, areaService, errorService, $stateParams, onSuccessDialogService, filtersService, commonService, STATUS_OPTIONS) {

    $scope.isModify = $stateParams.id ? true : false;

    $scope.area = {
        aname: '',
        id: ''
    }

    $scope.areaName = {
        areaId: ''
    }

    $scope.statusOptions = angular.copy(STATUS_OPTIONS);

    if ($scope.isModify) {
        areaService.getAreaNameDetails({ areaId: $stateParams.id })
        .then(function (data) {
            $scope.areaName = data.areaDetails;

            $scope.areaName.area = [{
                id: data.areaDetails.areaId,
                fields: {
                    aname: data.areaDetails.areaName
                }
            }]
        })
    }
    else {
        $scope.areaName = '';
    }

    filtersService.getAreaList()
    .then(function (success) {
        $scope.areaList = success.areaList;

    }, function (err) {
        commonService.error.show(err);
    });

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.saveAreaName = function (areaName) {

        $scope.areaName = areaName;
        if (areaName.area.length > 0) {
            $scope.areaName.areaId = areaName.area[0].id;
        }
        var msg = $scope.isModify ? 'Area Name updated successfully.' : 'Area Name added successfully.';

        areaService.addModifyName($scope.areaName)
        .then(function (res) {
            onSuccessDialogService.show(msg, function () {

                $state.go('logistics.home.areaMgt');

            })
        }, function (err) {
            commonService.error.show(err);
        });
    }

} ])


.controller('importAreaCtrl', ['$scope', '$state', '$rootScope', 'areaService', 'errorService', '$stateParams', 'modalService', 'SERVICE_CALL', 'commonService', 'onSuccessDialogService',
function ($scope, $state, $rootScope, areaService, errorService, $stateParams, modalService, SERVICE_CALL, commonService, onSuccessDialogService) {

    $scope.generateFileDataIcIus = {
        url: commonService.createServiceCallUrl(SERVICE_CALL.areaMgt.importFile),
        fields: '',
        sendFieldsAs: 'form'
    };

    $scope.hideLog = function () {
        $scope.showImportLog = false;
    }

    $scope.onFileSuccess = function (successObj, fileData) {

        var msg = 'Area have been imported successfully.';

        onSuccessDialogService.show(msg, function () {

            $scope.showAreaImportLog = true;
            // $scope.areaImportLog = successObj.data.importLog;

            $state.go('logistics.home.areaMgt');
        });

    }

    $scope.onFileFail = function (response, fileData) {

        errorService.show(response.err);
        $scope.areaFile = '';
    }

} ])