angular.module('logistics.area')
.factory('areaService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var areaService = {};

     areaService.getAreaLevelList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.getLevelList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     areaService.getAreaLevelDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.getLevelDetails, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     areaService.export = function () {
         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.exportArea))
        .success(function (res) {
         
            if (res.success) {
                deferred.resolve(res);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     areaService.addModifyLevel = function (level) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.addModifyLevel, level))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
          
        })

         return deferred.promise;
     }

     areaService.deleteAreaLevel = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.deleteLevel, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }           
        })
         return deferred.promise;

     }

     areaService.deleteAreaName = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.deleteName, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
         
        })
         return deferred.promise;

     }

     areaService.getAreaNamesList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.getAreaNamesList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     areaService.addModifyName = function (name) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.addModifyName, name))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }           
        })

         return deferred.promise;
     }

     areaService.getAreaNameDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.areaMgt.getAreaNameDetails, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }     

     return areaService;

 } ])