angular.module('logistics.dashboard')
.controller('dashboardCtrl', ['$scope', '$rootScope', 'commonService', 'dashboardService', 'filtersService',
function ($scope, $rootScope, commonService, dashboardService, filtersService) {

    $rootScope.shipmentCode = '';

    dashboardService.getShipmentList()
    .then(function (success) {
        $scope.shipmentList = success.dashboardshipmentList;
    }, function (err) {
        commonService.error.show(err);
    })

    filtersService.getStatusList()
    .then(function (success) {
        $scope.statusList = success.statusList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.filter = {
        status: '',
        area: [],
        locations: '',
        shipmentCode: ''
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

} ])

.controller('dashboardShipmentDetailsCtrl', ['$scope', '$rootScope', '$stateParams', 'commonService', 'dashboardService', 'filtersService',
function ($scope, $rootScope, $stateParams, commonService, dashboardService, filtersService) {

    $rootScope.shipmentCode = '';

    $scope.showNoRecordMsg = false;

    $scope.tabs = [{
        id: 'Overview',
        title: 'Overview'
    }, {
        id: 'Packages',
        title: 'Packages '
    }, {
        id: 'Map',
        title: 'Map '
    }];

    dashboardService.getShipmentDetail({ shipCode: $stateParams.shipmentCode })
    .then(function (success) {
        $scope.shipment = success.shipmentDetail;
        if ($scope.shipment.packageList == undefined) {
            $scope.shipment.packageList = '';
        }

        $scope.showNoRecordMsg = $scope.shipment.packageList.length == 0 ? true : false;

    }, function (err) {
        commonService.error.show(err);
    })

    $scope.showDetails = true;

    $scope.connectPoints = true;

} ])