angular.module('logistics.userManagement')
.factory('userManagementService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var userManagementService = {};

     userManagementService.getUsersList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.getUserList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     userManagementService.getUserDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.getUserDetails, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     userManagementService.addModifyUser = function (userDetails) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.addModifyUser, userDetails))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;
     }

     userManagementService.deleteUsers = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.deleteUser, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     userManagementService.getRoles = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.getRoles))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }


     userManagementService.checkLoginExist = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.checkLoginExist, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     userManagementService.forgotPassword = function (data) {
         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.forgotPassword, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     userManagementService.resetPassword = function (data) {
         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.userManagement.resetPassword, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     userManagementService.getCourierList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.getCourierList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }
     return userManagementService;

 } ])