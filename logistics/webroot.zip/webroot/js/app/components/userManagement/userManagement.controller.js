angular.module('logistics.userManagement')
.controller('userMgtCtrl', ['$scope', '$state', '$rootScope', 'userManagementService', 'errorService', '$stateParams', '$filter', 'modalService', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, userManagementService, errorService, $stateParams, $filter, modalService, PAGINATION_DEFAULT) {

    $rootScope.shipmentId = '';

    $scope.searchUser = {
        name: '',
        login: '',
        role: ''
    }

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    userManagementService.getUsersList().then(function (data) {
        $scope.usersList = data.usersList;
        $scope.showNoRecordMsg = data.usersList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    $scope.deleteUser = function (userId) {

        $scope.deleteSingleUserId = userId;
        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Users',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {
            confirmDelete();
        });
    }

    function confirmDelete() {

        var data = {
            userId: $scope.deleteSingleUserId
        }
        userManagementService.deleteUsers(data)
        .then(function (res) {

            $scope.usersList = $filter('filter')($scope.usersList, { id: ('!' + $scope.deleteSingleUserId) });
            $scope.deleteSingleUserId = '';
            $scope.showDeleteSucessMsg = true;

            $scope.paginationChanged();
        }, function (err) {
            errorService.show(err);
        });

    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.selectedUser = function (user) {
        if ($scope.checkAuthorization('ADMINISTRATION', 'USERS', 'R')) {
            $state.go('logistics.home.userMgt.overview', { userId: user.id });
        }
    }

} ])

.controller('addModifyUserCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'userManagementService', 'modalService', 'commonService', 'onSuccessDialogService', 'filtersService',
function ($scope, $rootScope, $stateParams, $state, userManagementService, modalService, commonService, onSuccessDialogService, filtersService) {

    $scope.modifyUser = $stateParams.userId ? true : false;

    $scope.userId = $stateParams.userId;

    $scope.loginIdExistMsg = false;

    $scope.passwordMismatch = false;

    $scope.showLocationErrorMsg = false;

    $scope.showCourierErrorMsg = false;

    $scope.showAreaErrorMsg = false;

    $rootScope.shipmentId = ''

    $scope.userRoles;

    //get all roles list
    userManagementService.getRoles()
    .then(function (data) {
        $scope.userRoles = data.roles;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.userDetails = {
        area: '',
        locationId: '',
        courierId: '',
        courierName: '',
        locationName: '',
        areaName: '',
        areaId: ''
    };

    if ($scope.modifyUser) {
        userManagementService.getUserDetails({ userId: $stateParams.userId })
        .then(function (data) {
            $scope.userDetails = data.userDetail;
            $scope.selectedRole = data.userDetail.role;

            $scope.userDetails.area = [{
                id: data.userDetail.areaId,
                fields: {
                    aname: data.userDetail.areaName
                }
            }]

            if ($scope.userDetails.userId == undefined) {
                $scope.userDetails.userId = '';
            }
            $scope.userDetails.userId = data.userDetail.id;
            $scope.oldLogin = data.userDetail.login;
        })
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.saveUser = function (userDetails) {
        $scope.passwordMismatch = false;

        var msg = $scope.modifyUser ? 'User updated successfully.' : 'User saved successfully.';

        if ($scope.userDetails.password !== $scope.userDetails.confirmPassword) {
            $scope.passwordMismatch = true;
        } else {
            if (!$scope.loginIdExistMsg) {
                if (userDetails.role == 'GENUSER1') { // for recipient
                    if (userDetails.area == undefined || userDetails.area == '') {
                        $scope.showAreaErrorMsg = true;
                        return;
                    }
                    else {
                        $scope.showAreaErrorMsg = false;
                    }
                    if (userDetails.locationId == undefined || userDetails.locationId == '') {
                        $scope.showLocationErrorMsg = true;
                        return;
                    }
                    else {
                        $scope.showLocationErrorMsg = false;
                    }
                    $scope.userDetails.courierId = '';
                    $scope.userDetails.courierName = '';
                }
                if (userDetails.role == 'GENUSER2') { // for courier
                    if (userDetails.courierId == undefined || userDetails.courierId == '') {
                        $scope.showCourierErrorMsg = true;
                        return;
                    }
                    $scope.userDetails.locationId = '';
                    $scope.userDetails.locationName = '';
                    $scope.userDetails.area = '';
                    $scope.userDetails.areaId = '';
                    $scope.userDetails.areaName = '';
                }

                userManagementService.addModifyUser(userDetails).then(function (res) {
                    if (res) {
                        onSuccessDialogService.show(msg, function () {
                            $state.go('logistics.home.userMgt');
                        })
                    }
                }, function (err) {
                    commonService.error.show(err);
                });
            }
        }
    }

    $scope.checkLoginExist = function (newLogin) {
        $scope.loginIdExistMsg = false;
        //check if the login id is changed or not, if changed the check in db
        if ($scope.oldLogin != newLogin) {
            var data = {
                login: newLogin,
                userId: $scope.userDetails.userId
            };
            userManagementService.checkLoginExist(data).then(function (res) {
                if (res.loginCheck != 0) {
                    $scope.loginIdExistMsg = true;
                }
            })
        } else {
            $scope.loginIdExistMsg = false;
        }
    }

    $scope.selectedUserRole = function (role) {

        $scope.selectedRole = role;
    }

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    })

    filtersService.getAreaList()
    .then(function (success) {
        $scope.areaList = success.areaList;

    }, function (err) {
        commonService.error.show(err);
    });

    userManagementService.getCourierList()
    .then(function (success) {
        $scope.courierList = success.courierList;
    }, function (err) {
        commonService.error.show(err);
    })

} ])

.controller('forgotPasswordCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'userManagementService', 'modalService', 'commonService', 'onSuccessDialogService',
function ($scope, $rootScope, $stateParams, $state, userManagementService, modalService, commonService, onSuccessDialogService) {

    $scope.userName = '';

    $scope.forgotPassword = function () {
        userManagementService.forgotPassword({ userName: $scope.userName })
        .then(function (success) {
            onSuccessDialogService.show('An e-mail was sent to reset your password.', function () {
                $state.go('logistics');
            })
        }, function (err) {
            commonService.error.show(err);
        })
    }

} ])

.controller('resetPasswordCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'userManagementService', 'modalService', 'commonService', 'onSuccessDialogService',
function ($scope, $rootScope, $stateParams, $state, userManagementService, modalService, commonService, onSuccessDialogService) {

    $scope.credentials = {
        userId: $stateParams.userId,
        password: ''
    }

    $scope.resetPassword = function () {
        userManagementService.resetPassword($scope.credentials)
        .then(function (success) {
            onSuccessDialogService.show('Password Changed Successfully', function () {
                $state.go('logistics');
            })
        }, function (err) {
            commonService.error.show(err);
        })
    }

} ])

.controller('userOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'userManagementService',
function ($scope, $rootScope, $stateParams, $state, userManagementService) {

    $scope.userId = $stateParams.userId;

    userManagementService.getUserDetails({ userId: $stateParams.userId })
        .then(function (data) {
            $scope.userDetails = data.userDetail;
        })
} ])