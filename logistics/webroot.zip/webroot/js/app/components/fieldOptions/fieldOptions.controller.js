angular.module('logistics.fieldOptions')
.controller('fieldOptionsCtrl', ['$scope', '$rootScope', 'commonService', 'modalService', '$filter', 'fieldOptionsService',
function ($scope, $rootScope, commonService, modalService, $filter, fieldOptionsService) {

    $rootScope.shipmentCode = '';

    //fieldOptionsService.getFieldTypes()
    //.then(function (success) {
    //    $scope.fieldTypes = success.fieldTypes;
    //    $scope.fieldTypeOptions = success.fieldTypeOptions;
    //}, function (err) {
    //    commonService.error.show(err);
    //})

    $scope.fieldTypes = [
        { id: 1, name: 'Package Types', parent: 'Package' },
        { id: 2, name: 'Location Types', parent: 'Location' },
        { id: 3, name: 'Courier Types', parent: 'Courier' },
        { id: 4, name: 'Item Types', parent: 'Item' }
    ]

    $scope.fieldTypeOptions = {
        1: [{ id: 1, name: 'Box', order: 1, visible: 1, 'default': 1, editable: 1, intCode: 1111, nationalCode: 1111122 },
            { id: 2, name: 'Square', order: 2, visible: 1, 'default': 0, editable: 0, intCode: '', nationalCode: ''},
            { id: 9, name: 'Test', order: 3, visible: 1, 'default': 0, editable: 0, intCode: '', nationalCode: ''}],
        2: [{ id: 3, name: 'Area 1', order: 1, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: '' },
            { id: 4, name: 'Area 2', order: 2, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: ''}],
        3: [{ id: 5, name: 'Courier 1', order: 1, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: '' },
            { id: 6, name: 'Courier 2', order: 2, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: ''}],
        4: [{ id: 7, name: 'Item 1', order: 1, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: '' },
            { id: 8, name: 'Item 2', order: 2, visible: 0, 'default': 0, editable: 0, intCode: '', nationalCode: ''}]
    }

    $scope.fieldTypeSelected = $scope.fieldTypes[0];

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deleteFieldOption = function (fieldOptionId, index) {

        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Field Options',
            bodyText: 'Are you sure you want to delete this record?'
        })
        .then(function (result) {
            confirmDelete(fieldOptionId, index);
        });


    }

    function confirmDelete(fieldOptionId, index) {

        var data = {
            fieldType: $scope.fieldTypeSelected.id,
            fieldOption: fieldOptionId
        }

        $scope.fieldTypeOptions[$scope.fieldTypeSelected.id].splice(index, 1);
    }

    $scope.sortableOptions = {
        handle: 'td > .reorder-icon',
        stop: function () {
            reorderFieldOptions();
        }
    }

    function reorderFieldOptions() {
        angular.forEach($scope.fieldTypeOptions[$scope.fieldTypeSelected.id], function (fieldTypeOption, index) {
            fieldTypeOption.order = index;
        })
    }

} ])

.controller('fieldOptionsOverviewCtrl', ['$scope', '$rootScope', '$stateParams', 'commonService', 'fieldOptionsService',
function ($scope, $rootScope, $stateParams, commonService, fieldOptionsService) {

    $scope.fieldType = $stateParams.fieldType;

    $scope.fieldOption = $stateParams.fieldOption;

    var data = {
        fieldType: $stateParams.fieldOption,
        fieldOption: $stateParams.fieldType
    }

    $scope.fieldOptionDetail = fieldOptionsService.getFieldDetails(data);

} ])

.controller('addModifyFieldOptionsCtrl', ['$scope', '$rootScope', '$stateParams', 'commonService', 'fieldOptionsService', 'onSuccessDialogService',
function ($scope, $rootScope, $stateParams, commonService, fieldOptionsService, onSuccessDialogService) {

    $scope.fieldType = $stateParams.fieldType;

    $scope.fieldOption = $stateParams.fieldOption || '';

    $scope.isModify = false;

    var data = {
        fieldType: $stateParams.fieldOption,
        fieldOption: $stateParams.fieldType
    }

    if ($stateParams.fieldOption) {
        $scope.isModify = true;
    }

    $scope.fieldOptionDetail = fieldOptionsService.getFieldDetails(data);

    $scope.saveFieldOptions = function () {

    }

} ])