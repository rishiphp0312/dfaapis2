angular.module('logistics.fieldOptions')
.factory('fieldOptionsService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {

    var fieldOptionsService = {};

    fieldOptionsService.getFieldTypes = function () {



    }

    fieldOptionsService.getFieldDetails = function (data) {
        return {
            id: data.fieldOption,
            name: 'Box',
            parent: 'Package',
            fieldTypeId: data.fieldType,
            fieldType: 'Package Types',
            order: 1,
            visible: 1,
            'default': 0,
            editable: 1,
            intCode: 1111,
            nationalCode: 1111122,
            modifiedBy: 'admin',
            modified: '2014-05-21'
        }
    }

    return fieldOptionsService;

} ])