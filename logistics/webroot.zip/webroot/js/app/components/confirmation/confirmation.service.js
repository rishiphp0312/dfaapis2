angular.module('logistics.confirmation')
.factory('confirmationService', ['$http', '$q', 'SERVICE_CALL', 'commonService', 'Upload',
function ($http, $q, SERVICE_CALL, commonService, Upload) {

    var confirmationService = {};

    confirmationService.getConformationList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.confirmations.getConformationList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    confirmationService.getConfirmationTypeList = function (data) {

        var deferred = $q.defer();
        $http(commonService.createHttpRequestObject(SERVICE_CALL.confirmations.getConfirmationTypeList, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
        return deferred.promise;
    }


    confirmationService.saveConfirmation = function (data, file) {

        var deferred = $q.defer();

        var data = {
            url: commonService.createHttpRequestObject(SERVICE_CALL.confirmations.saveConfirmation).url,
            fields: data,
            sendFieldsAs: 'form'
        }
        
        if (file) {
            data['file'] = file;
        }

        Upload.upload(data)
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
        return deferred.promise;
    }

    return confirmationService;

} ])