angular.module('logistics.confirmation')
.controller('confirmationCtrl', ['$scope', '$rootScope', '$state', 'confirmationService', 'commonService', 'filtersService', 'PAGINATION_DEFAULT', 'modalService', '$stateParams', '$filter',
function ($scope, $rootScope, $state, confirmationService, commonService, filtersService, PAGINATION_DEFAULT, modalService, $stateParams, $filter) {

    $rootScope.shipmentCode = '';

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    filtersService.getStatusList()
    .then(function (success) {

        $scope.statusList = success.statusList;

        confirmationService.getConformationList()
        .then(function (success) {
            $scope.deliveryList = success.deliveryList;

            $scope.showNoRecordMsg = $scope.deliveryList.length == 0 ? true : false;
            $scope.paginationChanged();
            $scope.pagination.currentPage = $stateParams.page || 1;
        }, function (err) {
            commonService.error.show(err);
        })

    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.filter = {
        status: '',
        area: [],
        locations: '',
        code: ''
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.shipmentSelected = function (shipment) {
        $state.go('logistics.home.confirmation.modify', { id: shipment.deliveryId });
    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

} ])

.controller('modifyConfirmationCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'confirmationService', 'commonService', 'deliveriesService', 'onSuccessDialogService','filtersService',
function ($scope, $rootScope, $stateParams, $state, confirmationService, commonService, deliveriesService, onSuccessDialogService, filtersService) {

    $scope.deliveryId = $stateParams.id;

    $scope.statusLis = {
        statusId: ''
    };

    $scope.attachments;

    deliveriesService.getDeliveryDetails({ deliveryId: $scope.deliveryId })
        .then(function (data) {
            $scope.confirmation = data.deliveryDetails;
            $scope.confirmation.point = data.deliveryDetails.toLocation;
        })

    filtersService.getStatusList()
    .then(function (success) {
        $scope.statusList = success.statusList;
        $scope.statusList.statusId = success.statusList.id;
    }, function (err) {
        commonService.error.show(err);
    })


    //get confirmation type
    confirmationService.getConfirmationTypeList({ code: 'ConfirmationType' }).then(function (data) {

        $scope.confirmationTypeList = data.typeList;
    },
    function (err) {
        commonService.error.show(err);
    });

    $scope.saveConfirmation = function (confirmation) {

        confirmation['id'] = $stateParams.id;
      
        confirmationService.saveConfirmation(confirmation, $scope.attachments ? $scope.attachments[0] : '')
        .then(function () {           
                onSuccessDialogService.show('Confirmation updated successfully.', function () {
                    $state.go('logistics.home.confirmation');
                })            
        }, function (err) {
            commonService.error.show(err);
        });

    }

} ])
