angular.module(appConfig.appName)
.run(['$rootScope', '$state', '$urlRouter', 'AUTH_EVENTS', 'authService',
 function ($rootScope, $state, $urlRouter, AUTH_EVENTS, authService) {
     $rootScope.$on('$stateChangeStart', function (event, next, params) {
         // if url is '/' OR Authentication required is true.
         // always check for authentication
         // if authenitcated than redirect to home 
         if (next.url == '/' || (next.data != undefined && next.data.authenticationRequired == true)) {
             authService.isAuthenticated()
             .then(function (isAuthenticated) {
                 if (next.url == '/') {
                     if (isAuthenticated) {
                         event.preventDefault();
                         $state.go('logistics.home');
                     }
                 } else if (next.data.authenticationRequired) {
                     if (isAuthenticated) {
                         if (!authService.isAuthorized(next.data.module, next.data.submodule, next.data.action)) {
                             event.preventDefault();
                             $state.go('logistics.notAuthorized');
                         }
                     } else {
                         event.preventDefault();
                         location.href = _WEBSITE_URL;
                     }
                 }
             })
         }
     });
 } ])

.config(['$stateProvider', '$urlRouterProvider', '$httpProvider', 'localStorageServiceProvider', 'MODULES', 'SUBMODULES', 'ACTIONS',
function ($stateProvider, $urlRouterProvider, $httpProvider, localStorageServiceProvider, MODULES, SUBMODULES, ACTIONS) {

    localStorageServiceProvider
        .setPrefix(appConfig.appName);

    $httpProvider.interceptors.push('authInterceptor');

    $urlRouterProvider.otherwise('/');

    var baseFolderUrl = 'js/app/components/';

    $stateProvider

    .state('logistics', {
        url: '/',
        views: {
            'content': {
                templateUrl: baseFolderUrl + 'core/views/login.html'
            },
            'footer': {
                templateUrl: baseFolderUrl + 'core/views/footer.html'
            }
        },
        data: {
            authenticationRequired: false
        }
    })

    .state('logistics.notAuthorized', {
        url: 'NotAuthorized',
        views: {
            'header@': {
                templateUrl: baseFolderUrl + 'core/views/header.html'
            },
            'content@': {
                templateUrl: baseFolderUrl + 'core/views/notAuthorized.html'
            }
        }
    })

    .state('logistics.forgotPassword', {
        url: 'ForgotPassword',
        views: {
            'header@': {
                templateUrl: baseFolderUrl + 'core/views/header.html'
            },
            'content@': {
                templateUrl: baseFolderUrl + 'core/views/forgotPassword.html',
                controller: 'forgotPasswordCtrl'
            }
        },
        data: {
            authenticationRequired: false
        }
    })

    .state('logistics.resetPassword', {
        url: 'ResetPassword/:userId',
        views: {
            'header@': {
                templateUrl: baseFolderUrl + 'core/views/header.html'
            },
            'content@': {
                templateUrl: baseFolderUrl + 'core/views/resetPassword.html',
                controller: 'resetPasswordCtrl'
            }
        },
        data: {
            authenticationRequired: false
        }

    })

    /** HOME PAGE **/
    .state('logistics.home', {
        url: 'Home',
        views: {
            'header@': {
                templateUrl: baseFolderUrl + 'core/views/header.html'
            },
            'content@': {
                templateUrl: baseFolderUrl + 'home/views/index.html',
                controller: 'homeCtrl'
            },
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'shipment/views/index.html',
                controller: 'shipmentsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.SHIPMENT,
            action: ACTIONS.R
        }

    })

    /*SHIPMENT*/
    .state('logistics.home.shipment', {
        url: '^/Shipment/:shipmentCode'
    })

    .state('logistics.home.shipment.add', {
        url: '^/AddShipment',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'shipment/views/addModify.html',
                controller: 'addModifyShipmentCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.SHIPMENT,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.shipment.overview', {
        url: '/Overview',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'shipment/views/overview.html',
                controller: 'shipmentOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.SHIPMENT,
            action: ACTIONS.R
        }

    })

    .state('logistics.home.shipment.modify', {
        url: '/Modify',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'shipment/views/addModify.html',
                controller: 'addModifyShipmentCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.SHIPMENT,
            action: ACTIONS.U
        }
    })

    /*PACKAGES*/
    .state('logistics.home.shipment.packages', {
        url: '/Packages',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'packages/views/index.html',
                controller: 'packagesCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.PACKAGES,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.shipment.packages.overview', {
        url: '/Overview/:packageCode',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'packages/views/overview.html',
                controller: 'packageOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.PACKAGES,
            action: ACTIONS.R
        }

    })

    .state('logistics.home.shipment.packages.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'packages/views/addModifyPackage.html',
                controller: 'addModifyPackageCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.PACKAGES,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.shipment.packages.modify', {
        url: '/Modify/:packageCode',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'packages/views/addModifyPackage.html',
                controller: 'addModifyPackageCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.SHIPMENTS,
            submodule: SUBMODULES.PACKAGES,
            action: ACTIONS.U
        }
    })

    /** DELIVERIES **/
    .state('logistics.home.deliveries', {
        url: '^/Deliveries',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'deliveries/views/index.html',
                controller: 'deliveriesCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.FREIGHT,
            submodule: SUBMODULES.DELIVERIES,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.deliveries.modify', {
        url: '/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'deliveries/views/modify.html',
                controller: 'modifyDeliveryCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.FREIGHT,
            submodule: SUBMODULES.DELIVERIES,
            action: ACTIONS.U
        }
    })

    /** CONFIRMATIONS **/
    .state('logistics.home.confirmation', {
        url: '^/Confirmation',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'confirmation/views/index.html',
                controller: 'confirmationCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.FREIGHT,
            submodule: SUBMODULES.CONFIRMATIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.confirmation.modify', {
        url: '/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'confirmation/views/modifyConfirmation.html',
                controller: 'modifyConfirmationCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.FREIGHT,
            submodule: SUBMODULES.CONFIRMATIONS,
            action: ACTIONS.U
        }
    })

    /** AREA MGMT **/
    .state('logistics.home.areaMgt', {
        url: '/Area',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/index.html',
                controller: 'areaMgtCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.areaMgt.addLevel', {
        url: '/AreaLevel/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/addModifyLevel.html',
                controller: 'addModifyLevelCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.areaMgt.modifyLevel', {
        url: '/AreaLevel/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/addModifyLevel.html',
                controller: 'addModifyLevelCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.U
        }
    })

    .state('logistics.home.areaMgt.addName', {
        url: '/AreaName/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/addModifyName.html',
                controller: 'addModifyNameCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.areaMgt.import', {
        url: '/Import',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/import.html',
                controller: 'importAreaCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.areaMgt.modifyName', {
        url: '/AreaName/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'area/views/addModifyName.html',
                controller: 'addModifyNameCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.AREAS,
            action: ACTIONS.U
        }
    })

    /** USER MANAGEMENT **/
    .state('logistics.home.userMgt', {
        url: '/Users',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'userManagement/views/index.html',
                controller: 'userMgtCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.USERS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.userMgt.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'userManagement/views/addModifyUser.html',
                controller: 'addModifyUserCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.USERS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.userMgt.modify', {
        url: '/Modify/:userId',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'userManagement/views/addModifyUser.html',
                controller: 'addModifyUserCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.USERS,
            action: ACTIONS.U
        }
    })

    .state('logistics.home.userMgt.overview', {
        url: '/Overview/:userId',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'userManagement/views/overview.html',
                controller: 'userOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.USERS,
            action: ACTIONS.R
        }

    })

    /** ITEMS **/
    .state('logistics.home.itemMgt', {
        url: '/Items',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'item/views/index.html',
                controller: 'itemMgtCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.ITEMS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.itemMgt.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'item/views/addModify.html',
                controller: 'addModifyItemCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.ITEMS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.itemMgt.modify', {
        url: '/Modify/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'item/views/addModify.html',
                controller: 'addModifyItemCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.ITEMS,
            action: ACTIONS.U
        }
    })

    .state('logistics.home.itemMgt.overview', {
        url: '/Overview/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'item/views/overview.html',
                controller: 'itemOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.ITEMS,
            action: ACTIONS.R
        }
    })


    /**  COURIERS **/
    .state('logistics.home.courierMgt', {
        url: '/Couriers',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'courier/views/index.html',
                controller: 'courierMgtCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.COURIERS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.courierMgt.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'courier/views/addModify.html',
                controller: 'addModifyCourierCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.COURIERS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.courierMgt.modify', {
        url: '/Modify/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'courier/views/addModify.html',
                controller: 'addModifyCourierCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.COURIERS,
            action: ACTIONS.U
        }
    })

        .state('logistics.home.courierMgt.overview', {
            url: '/Overview/:id',
            views: {
                'moduleView@logistics.home': {
                    templateUrl: baseFolderUrl + 'courier/views/overview.html',
                    controller: 'CourierOverviewCtrl'
                }
            },
            data: {
                authenticationRequired: true,
                module: MODULES.ADMINISTRATION,
                submodule: SUBMODULES.COURIERS,
                action: ACTIONS.R
            }
        })

    /**  SUBSCRIPTION **/
    .state('logistics.home.subscription', {
        url: '/Subscriptions',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'subscriptions/views/index.html',
                controller: 'subscriptionsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.SUBSCRIPTIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.subscription.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'subscriptions/views/addModify.html',
                controller: 'addModifySubscriptionCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.SUBSCRIPTIONS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.subscription.modify', {
        url: '/Modify/:id',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'subscriptions/views/addModify.html',
                controller: 'addModifySubscriptionCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.SUBSCRIPTIONS,
            action: ACTIONS.U
        }
    })

        .state('logistics.home.subscription.overview', {
            url: '/Overview/:id',
            views: {
                'moduleView@logistics.home': {
                    templateUrl: baseFolderUrl + 'subscriptions/views/overview.html',
                    controller: 'subscriptionOverviewCtrl'
                }
            },
            data: {
                authenticationRequired: true,
                module: MODULES.ADMINISTRATION,
                submodule: SUBMODULES.SUBSCRIPTIONS,
                action: ACTIONS.R
            }
        })


    /** REPORTS **/
    .state('logistics.home.reports', {
        url: '^/Reports'
    })

    /** DASHBOARD **/
    .state('logistics.home.reports.dashboard', {
        url: '/Dashboard',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'dashboard/views/index.html',
                controller: 'dashboardCtrl'
            }
        },
        date: {
            authenticationRequired: false,
            module: MODULES.REPORTS,
            submodule: SUBMODULES.DASHBOARD,
            action: ACTIONS.R

        }

    })

    .state('logistics.home.reports.dashboard.shipmentDetails', {
        url: '/Shipment/:shipmentCode',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'dashboard/views/shipmentDetails.html',
                controller: 'dashboardShipmentDetailsCtrl'
            }
        },
        date: {
            authenticationRequired: false,
            module: MODULES.REPORTS,
            submodule: SUBMODULES.DASHBOARD,
            action: ACTIONS.R
        }
    })

    /** MAP **/
    .state('logistics.home.reports.map', {
        url: '/Map',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'map/views/index.html',
                controller: 'mapsCtrl'
            }
        },
        date: {
            authenticationRequired: false,
            module: MODULES.REPORTS,
            submodule: SUBMODULES.MAP,
            action: ACTIONS.R
        }

    })

    /** PACKING LIST **/
    .state('logistics.home.reports.packingList', {
        url: '/PackingList',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'packingList/views/index.html',
                controller: 'packingListCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.REPORTS,
            submodule: SUBMODULES.SHIPMENT_LABELS,
            action: ACTIONS.R
        }
    })

    /**SHIPMENT LABELS **/
    .state('logistics.home.reports.shipmentLabels', {
        url: '/ShipmentLabels',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'shipmentLabels/views/index.html',
                controller: 'shipmentLabelsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.REPORTS,
            submodule: SUBMODULES.SHIPMENT_LABELS,
            action: ACTIONS.R
        }
    })

    /** ADMINISTRATION **/
    .state('logistics.home.administration', {
        url: '^/Administration'
    })

    .state('logistics.home.administration.configurations', {
        url: '/Configurations',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'configurations/views/index.html',
                controller: 'configurationsCtrl'
            }
        },
        date: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.CONFIGURATIONS,
            action: ACTIONS.R
        }
    })

    /** LOCATIONS **/
    .state('logistics.home.location', {
        url: '^/Locations',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'location/views/index.html',
                controller: 'locationCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.LOCATIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.location.overview', {
        url: '/Overview/:locationId',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'location/views/overview.html',
                controller: 'locationOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.LOCATIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.location.add', {
        url: '/Add',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'location/views/addModify.html',
                controller: 'addModifyLocationCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.LOCATIONS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.location.modify', {
        url: '/Modify/:locationId',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'location/views/addModify.html',
                controller: 'addModifyLocationCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.LOCATIONS,
            action: ACTIONS.U
        }
    })

    /** FIELD OPTIONS **/
    .state('logistics.home.fieldOptions', {
        url: '^/FieldOptions',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'fieldOptions/views/index.html',
                controller: 'fieldOptionsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.FIELD_OPTIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.fieldOptions.overview', {
        url: '/Overview/:fieldType/:fieldOption',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'fieldOptions/views/overview.html',
                controller: 'fieldOptionsOverviewCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.FIELD_OPTIONS,
            action: ACTIONS.R
        }
    })

    .state('logistics.home.fieldOptions.add', {
        url: '/Add/:fieldType',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'fieldOptions/views/addModify.html',
                controller: 'addModifyFieldOptionsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.FIELD_OPTIONS,
            action: ACTIONS.C
        }
    })

    .state('logistics.home.fieldOptions.modify', {
        url: '/Modify/:fieldType/:fieldOption',
        views: {
            'moduleView@logistics.home': {
                templateUrl: baseFolderUrl + 'fieldOptions/views/addModify.html',
                controller: 'addModifyFieldOptionsCtrl'
            }
        },
        data: {
            authenticationRequired: true,
            module: MODULES.ADMINISTRATION,
            submodule: SUBMODULES.FIELD_OPTIONS,
            action: ACTIONS.U
        }
    })


} ])