angular.module(appConfig.appName)
.service('session', ['$rootScope', '$cookieStore',
function ($rootScope, $cookieStore) {
    // creates the cookie for current user and also stores user information in root scope.
    this.create = function (sessionId, user) {
        this.id = sessionId;
        this.user = user;
        $rootScope.currentUser = user;
        $cookieStore.put('globals', user);
    };

    this.destroy = function () {
        this.id = null;
        this.user = null;
        $rootScope.currentUser = null;
        $cookieStore.remove('globals');
    };

} ])

.factory('authService', ['$http', '$q', 'session', '$rootScope', '$cookieStore', 'commonService', 'SERVICE_CALL',
function ($http, $q, session, $rootScope, $cookieStore, commonService, SERVICE_CALL) {

    var authService = {};

    // login
    authService.login = function (credentials) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(undefined, credentials, SERVICE_CALL.system.login))
        .success(function (res) {
            if (res.success) {
                var data = res.data;
                session.create(data.id, data.user);
                deferred.resolve(true);
            } else {
                deferred.reject(res.err);
            }
        });

        return deferred.promise;

    }

    // logout for user.
    authService.logout = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(undefined, undefined, SERVICE_CALL.system.logout))
        .then(function (res) {
            session.destroy();
            commonService.localStorage.clearAll();
            deferred.resolve(true);
        });

        return deferred.promise;

    }

    authService.destroySession = function () {
        session.destroy();
        commonService.localStorage.clearAll();
    }

    // check if user is logged in
    authService.isAuthenticated = function () {

        var deferred = $q.defer();

        var user = $cookieStore.get('globals');

        // if user id found in cookie than request is authetnicated else check via service call.
        if (angular.isUndefined(user) || angular.isUndefined(user.id)) {
            $http(commonService.createHttpRequestObject(SERVICE_CALL.system.checkSessionDetails))
            .success(function (res) {
                if (res.success) {
                    var data = res.data;
                    session.create(data.id, data.user);
                    deferred.resolve(true);
                } else {
                    session.destroy();
                    deferred.resolve(false);
                }
            });
        } else {
            $rootScope.currentUser = user;
            deferred.resolve(true);
        }

        return deferred.promise;

    };

    /* 
    * check if user is Authorized -- incase of super admin always authorized.
    * input param: authorizedRoles- required role to authorize.
    */
    authService.isAuthorized = function (module, submodule, action) {

        var deferred = $q.defer();

        var authorized = false;

        var permissions = authService.getPermissions();

        if (permissions) {
            if (permissions[module] && permissions[module][submodule]) {
                authorized = permissions[module][submodule][action] || false;
            }
        }

        return authorized;
    };

    authService.getPermissions = function () {

        var user = $cookieStore.get('globals');

        return user.permission || '';

    }

    return authService;

} ])

.factory('commonService', ['$http', '$q', 'SERVICE_CALL', 'localStorageService', 'errorService', 'base64ConversionService',
function ($http, $q, SERVICE_CALL, localStorageService, errorService, base64ConversionService) {

    var commonService = {};

    commonService.createServiceCallUrl = function (serviceCall) {
        return appConfig.serviceCallUrl + serviceCall;
    }

    //creates HTTP request Object as per params Passed.
    commonService.createHttpRequestObject = function (serviceCall, data, url, method, headers) {

        var req = {};
        req['method'] = method || 'POST';

        if (serviceCall) {
            req['url'] = commonService.createServiceCallUrl(serviceCall);
        } else if (url) {
            req['url'] = url;
        }

        if (data) {
            req['data'] = $.param(data);
        }

        req['headers'] = headers || { 'Content-Type': 'application/x-www-form-urlencoded' };

        return req;
    }

    // sets a default value for a property if property does not exist in an object
    commonService.ensureDefault = function (obj, prop, value) {
        if (!obj.hasOwnProperty(prop))
            obj[prop] = value;
    }

    commonService.getAreaOnDemandURL = function () {
        return commonService.createServiceCallUrl(SERVICE_CALL.filters.getAreaList);
    }

    // Local Storage
    commonService.localStorage = {};

    commonService.localStorage.checkSupport = function () {
        return localStorageService.isSupported;
    }

    commonService.localStorage.setDbIfDoesntExist = function (key) {
        if (commonService.localStorage.getDb(key) == null) {
            return localStorageService.set(key, {});
        }
        return false;
    }

    commonService.localStorage.setDb = function (key, value) {
        return localStorageService.set(key, value);
    }

    commonService.localStorage.getDb = function (key, createIfDoesntExist) {
        var value = localStorageService.get(key);
        if (value == null && createIfDoesntExist) {
            value = {};
            commonService.localStorage.setDb(key, value);
        }
        return value;
    }

    commonService.localStorage.getUserPreference = function (dbId, moduleType, key) {

        var userPreference = undefined;

        var dbPreference = commonService.localStorage.getDb(dbId);

        if (dbPreference != null) {
            if (dbPreference[moduleType]) {
                userPreference = dbPreference[moduleType][key];
            }
        }

        return userPreference;
    }

    commonService.localStorage.setUserPreference = function (dbId, moduleType, key, value) {

        var dbPreference = commonService.localStorage.getDb(dbId, true);

        if (dbPreference[moduleType]) {
            dbPreference[moduleType][key] = value;
        } else {
            dbPreference[moduleType] = {};
            dbPreference[moduleType][key] = value;
        }

        return commonService.localStorage.setDb(dbId, dbPreference);

    }

    commonService.localStorage.clearAll = function () {
        return localStorageService.clearAll();
    }

    commonService.error = errorService;

    commonService.base64 = base64ConversionService;

    return commonService;

} ])

.factory('errorService', ['ERROR_CODE', 'modalService',
function (ERROR_CODE, modalService) {

    var errorService = {};

    errorService.resolve = function (errObj) {

        var errorMessage = 'An error occurred during the process.';

        if (errObj != undefined) {

            if (errObj.code != undefined && errObj.code != '') {
                errorMessage = ERROR_CODE[errObj.code];
            } else if (angular.isDefined(errObj.msg)) {
                errorMessage = errObj.msg;
            }

        }

        return errorMessage;

    }

    errorService.show = function (errObj) {
        modalService.show({}, {
            actionButtonText: 'OK',
            headerText: 'Error',
            bodyText: errorService.resolve(errObj),
            showCloseButton: false
        })
    }

    return errorService;

} ])

.service('modalService', ['$modal',
function ($modal) {

    var modalOptions = {
        closeButtonText: 'Close',
        actionButtonText: 'OK',
        headerText: 'Confirmation',
        bodyText: 'Are you sure you want to perform this action?',
        showCloseButton: true
    };

    var modalDefaults = {
        backdrop: true,
        keyboard: true,
        templateUrl: 'js/app/components/core/views/modal.html'
    };

    this.show = function (customModalDefaults, customModalOptions) {
        //Create temp objects to work with since we're in a singleton service
        var tempModalDefaults = {};
        var tempModalOptions = {};

        //Map angular-ui modal custom defaults to modal defaults defined in service
        angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

        //Map modal.html $scope custom properties to defaults defined in service
        angular.extend(tempModalOptions, modalOptions, customModalOptions);

        if (!tempModalDefaults.controller) {
            tempModalDefaults.controller = function ($scope, $modalInstance) {
                $scope.modalOptions = tempModalOptions;
                $scope.confirm = function (result) {
                    $modalInstance.close(result);
                };
                $scope.close = function (result) {
                    $modalInstance.dismiss('cancel');
                };
            }
        }

        return $modal.open(tempModalDefaults).result;
    };

} ])

.factory('authInterceptor', function ($rootScope, $q, AUTH_EVENTS) {
    return {
        responseError: function (response) {
            switch (response.status) {
                case 401:
                    $rootScope.$emit(AUTH_EVENTS.notAuthenticated);
                    return $q.reject(response);
                    break;
                case 403:
                    alert('Unauthorized');
                    return $q.reject(response);
                    break;
                case 500:
                    alert('Soemthing went wrong: Internal Server Error');
                    return $q.reject(response);
                    break;
                default:
                    return $q.reject(response);
            }
        }
    };
})

.factory('base64ConversionService', function () {

    var base64ConversionService = {};

    var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

    base64ConversionService.encode = function (input) {

        var output = "";
        var chr1, chr2, chr3 = "";
        var enc1, enc2, enc3, enc4 = "";
        var i = 0;

        do {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output +
                    keyStr.charAt(enc1) +
                    keyStr.charAt(enc2) +
                    keyStr.charAt(enc3) +
                    keyStr.charAt(enc4);
            chr1 = chr2 = chr3 = "";
            enc1 = enc2 = enc3 = enc4 = "";
        } while (i < input.length);

        return output;

    }

    base64ConversionService.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3 = "";
        var enc1, enc2, enc3, enc4 = "";
        var i = 0;

        // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
        var base64test = /[^A-Za-z0-9\+\/\=]/g;
        if (base64test.exec(input)) {
            console.error("There were invalid base64 characters in the input text.\n" +
                    "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                    "Expect errors in decoding.");
        }

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        do {
            enc1 = keyStr.indexOf(input.charAt(i++));
            enc2 = keyStr.indexOf(input.charAt(i++));
            enc3 = keyStr.indexOf(input.charAt(i++));
            enc4 = keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

            chr1 = chr2 = chr3 = "";
            enc1 = enc2 = enc3 = enc4 = "";

        } while (i < input.length);

        return output;
    }

    return base64ConversionService;

})

.factory('onSuccessDialogService', ['modalService',
function (modalService) {

    var onSuccessDialogService = {};

    onSuccessDialogService.show = function (msg, callBack) {
        modalService.show({ backdrop: false }, {
            actionButtonText: 'OK',
            headerText: 'Success',
            bodyText: msg,
            showCloseButton: false
        }).then(function (result) {
            if (callBack != undefined) {
                callBack();
            }
        })
    }
    return onSuccessDialogService;

} ])

.factory('filtersService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {
    var filtersService = {};

    filtersService.getStatusList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.filters.getStatusList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    filtersService.getLocationList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.filters.getLocationList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    filtersService.getAreaList = function (addAllAreas) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.filters.getAreaList, { onDemand: true }))
        .success(function (res) {
            if (res.success) {
                if (addAllAreas) {
                    res.data.areaList.unshift({
                        id: '',
                        fields: {
                            aname: 'All Areas'
                        }
                    })
                }
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }


    filtersService.areaTreeViewOptions = function () {
        return {
            onDemand: true,
            useICheck: true,
            onDemandOptions: {
                url: commonService.getAreaOnDemandURL(),
                responseDataKey: ['data', 'areaList'],
                requestDataKey: 'returnData'
            },
            selectionOptions: {
                multiSelection: false,
                showCheckBox: false,
                checkBoxClass: '',
                selectedClass: 'nodeSelected'
            },
            nodeOptions: {
                showNodeOpenCloseClass: true,
                nodeOpenClass: 'fa fa-plus',
                nodeCloseClass: 'fa fa-minus',
                showNodeLeafClass: false,
                nodeLeafClass: '',
                showLoader: true,
                loaderClass: 'fa fa-spinner fa-spin'
            },
            labelOptions: {
                fields: [{
                    id: 'aname',
                    css: '',
                    seperator: ''
                }],
                prefix: '',
                suffix: '',
                class: ''
            }
        }
    }

    filtersService.dropdownProperties = function () {
        return {
            search: false,
            showSelected: false,
            autoSelect: true,
            placeholder: 'All Areas'
        }
    }

    return filtersService;
} ])