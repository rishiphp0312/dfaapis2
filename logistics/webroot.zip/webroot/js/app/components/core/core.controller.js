angular.module(appConfig.appName)
.controller('appController', ['$scope', '$rootScope', '$stateParams', '$state', 'AUTH_EVENTS', 'authService', 'commonService',
function ($scope, $rootScope, $stateParams, $state, AUTH_EVENTS, authService, commonService) {

    $scope.loginFailed = false;

    $scope.credentials = {
        username: '',
        password: ''
    }

    $scope.login = function (credentials) {
        authService.login(credentials)
        .then(function (success) {
            $state.go('logistics.home');
        }, function (err) {
            $scope.loginFailedMsg = commonService.error.resolve(err);
            $scope.loginFailed = true;
        })
    }

    $scope.logout = function () {
        authService.logout()
        .then(function (success) {
            location.href = _WEBSITE_URL;
        })
    }

    $rootScope.$on(AUTH_EVENTS.notAuthenticated, function () {
        authService.destroySession();
        location.href = _WEBSITE_URL;
    })


    $scope.checkAuthorization = function (module, submodule, action) {

        var isAuthorized = false;

        isAuthorized = authService.isAuthorized(module, submodule, action)

        return isAuthorized;
    }

    $scope.exceptEmptyComparator = function (actual, expected) {
        if (!expected) {
            return true;
        }
        return angular.equals(expected, actual);
    }

    $scope.systemConfig = _SYSCONFIG;

} ]);