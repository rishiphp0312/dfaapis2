angular.module(appConfig.appName)
.constant('AUTH_EVENTS', {
    loginSuccess: 'auth-login-success',
    loginFailed: 'auth-login-failed',
    logoutSuccess: 'auth-logout-success',
    sessionTimeout: 'auth-session-timeout',
    notAuthenticated: 'auth-not-authenticated',
    notAuthorized: 'auth-not-authorized',
    setCurrentUser: 'set-current-user'
})
.constant('CALENDER_FORMAT', {
    'yyyy-MM-dd': 'yyyy-MM-dd',
    'dd-MMMM-yyyy': 'dd-MMMM-yyyy',
    'yyyy/MM/dd': 'yyyy/MM/dd',
    'dd-MM-yyyy': 'dd-MM-yyyy',
    'shortDate': 'shortDate'
})
.constant('CALENDER_DATE_OPT', {
    formatYear: 'yyyy',
    startingDay: 1
})
.constant('SERVICE_CALL', {
    system: {
        login: 'users/login',
        logout: 'users/logout',
        checkSessionDetails: '500'
    },
    shipment: {
        getShipmentList: 106,
        generateShipmentCode: 110,
        saveShipment: 107,
        getShipmentDetails: 108,
        getConfirmationList: 503,
        deleteShipment: 111
    },
    userManagement: {
        getUserList: 404,
        deleteUser: 405,
        getUserDetails: 406,
        getRoles: 502,
        addModifyUser: 403,
        checkLoginExist: 102,
        forgotPassword: 401,
        resetPassword: 402
    },
    filters: {
        getStatusList: 407,
        getLocationList: 408,
        getAreaList: 409
    },
    packages: {
        getPackageList: 101,
        getPackageTypeList: 503,
        getItemsList: 103,
        generatePackageCode: 104,
        addModifyPackage: 105,
        getPackageDetails: 113,
        deletePackage: 112
    },
    courier: {
        getCourierList: 518,
        getCourierDetails : 519,
        getItemTypeList:503,
        addModify:521,
        deleteCourier:520
    },
    deliveries: {
        getDeliveryDetails: 201,
        getShipmentList: 205,
        deleteDelivery: 210,
        saveDelivery: 203
    },
    confirmations: {
        getConformationList: 206,
        deleteConfirmation: 211,
        getConfirmationTypeList: 503,
        saveConfirmation: 204
    },
    dashboard: {
        getShipmentList: 302,
        getShipmentDetail: 303
    },
    shipmentLabels: {
        getShipmentList: 304
    },
    packingLabel: {
        getPackingList: 304
    },
    map: {
        getShipmentList: 302
    },
    areaMgt: {
        importFile: 504,
        exportArea: 505,
        getLevelList: 508,
        getLevelDetails: 509,
        addModifyLevel: 506,
        deleteLevel: 507,
        deleteName: 513,
        getAreaNamesList: 510,
        addModifyName: 512,
        getAreaNameDetails: 511
    },
    configurations: {
        getConfigurations: 423,
        modifyConfigurations: 424
    },
    location: {
        getLocationList: 419,
        deleteLocation: 418,
        getLocationDetail: 416,
        getLocationType: 503,
        saveLocation: 417
    },
    subscriptions: {
        getSubscriptionList: 413,
        getSubscriptionDetails: 411,
        addModify: 412,
        deleteSubscription: 414
    },
    items: {
        getItemsList: 514,
        deleteItem: 516,
        getItemDetails: 515,
        getItemTypeList: 503,
        addModifyItem: 517
    },
    fieldOptions: {

    }
})
.constant('PAGINATION_DEFAULT', {
    pageSize: 10,
    currentPage: 1,
    from: 1,
    to: 10,
    totalCount: '',
    pageSizes: [10, 20, 30, 40, 50]
})
.constant('ERROR_CODE', {
    'ERR100': 'Operation not completed due to server error',
    'ERR101': 'Email is empty',
    'ERR102': 'Email not found in database',
    'ERR103': 'Invalid Email format',
    'ERR104': 'Email length greater than 100',
    'ERR105': 'Missing parameters',
    'ERR106': 'Username is empty',
    'ERR107': 'First name is empty',
    'ERR108': 'Last name is  empty',
    'ERR109': 'Username length is  greater than 50',
    'ERR110': 'First name length greater than 50',
    'ERR111': 'Last name length greater than 50',
    'ERR112': 'Username already exists',
    'ERR113': 'Role is empty',
    'ERR114': 'Role is invalid',
    'ERR115': 'Activation link already used',
    'ERR116': '',
    'ERR117': 'Invalid activation key',
    'ERR118': 'Key is empty',
    'ERR119': 'Password is empty',
    'ERR120': 'Email already exists',
    'ERR121': 'Password length is greater than 50',
    'ERR122': 'Password not matched with confirm password',
    'ERR123': 'Package code empty',
    'ERR124': 'Package code length is greater than 17',
    'ERR125': 'Package code already exists',
    'ERR126': '',
    'ERR127': 'Invalid request',
    'ERR128': 'Weight length is greater than 20',
    'ERR129': 'Package item quantity  length is greater than 5',
    'ERR130': 'Item code is empty',
    'ERR131': 'From Area is required',
    'ERR132': 'From Location is required',
    'ERR133': 'To Area is required',
    'ERR134': 'To Location is required',
    'ERR135': 'Shipment code is empty',
    'ERR136': 'Weight is empty.',
    'ERR137': 'No records found.',
    'ERR138': 'Empty package items.',
    'ERR139': 'Comments length  greater than 65535.',
    'ERR140': 'No package found for this shipment.',
    'ERR142': 'Username does not exists.',
    'ERR143': 'Activation link is expired.',
    'ERR144': 'Duplicate items exists.',
    'ERR145': 'File is empty.',
    'ERR146': 'Invalid columns format.',
    'ERR147': 'Area level code is empty.',
    'ERR148': 'Area level name is empty.',
    'ERR149': 'level code already exist .',
    'ERR150': 'level code length exceeded.',
    'ERR151': 'level name  already exist.',
    'ERR152': 'level name  length exceeded.',
    'ERR158': 'Item code length exceeded than 20.',
    'ERR159': 'Item code already exists.',
    'ERR160': 'Item Name length exceeded than 50 .',
    'ERR161': 'Item Name already exists.',
    'ERR162': ' Courier Code already exists.',
    'ERR163': 'Courier Name length exceeded than 50.',
    'ERR164': 'Courier Code length exceeded than 20.',
    'ERR165': ' Courier Contact length exceeded than 50.',
    'ERR166': 'Courier Phone length exceeded than 20.',
    'ERR167': 'Courier Email length exceeded than 100.',
    'ERR168': 'Courier Name already exists.',
    'ERR169': 'Courier code  is empty .',
    'ERR170': 'Courier name  is empty.',
    'ERR171': 'Contact is  empty.',
    'ERR172': 'Contact length exceeded than 50.',
    'ERR173': 'Phone is  empty.',
    'ERR174': 'Phone length exceeded than 20 .',
    'ERR175': 'Email is  empty.',
    'ERR176': 'Email length exceeded than 50.',
    'ERR177': 'Fax length exceeded than 20.',
})
.constant('MODULES', {
    ADMINISTRATION: 'ADMINISTRATION',
    FREIGHT: 'FREIGHT',
    REPORTS: 'REPORTS',
    SHIPMENTS: 'SHIPMENTS'
})
.constant('SUBMODULES', {
    SHIPMENT: 'SHIPMENT',
    PACKAGES: 'PACKAGES',
    AREAS: 'AREAS',
    CONFIGURATIONS: 'CONFIGURATIONS',
    COURIERS: 'COURIERS',
    CUSTOM_FIELDS: 'CUSTOM_FIELDS',
    FIELD_OPTIONS: 'FIELD_OPTIONS',
    ITEMS: 'ITEMS',
    LOCATIONS: 'LOCATIONS',
    STATUS: 'STATUS',
    SUBSCRIPTIONS: 'SUBSCRIPTIONS',
    TRANSLATIONS: 'TRANSLATIONS',
    USERS: 'USERS',
    CONFIRMATIONS: 'CONFIRMATIONS',
    DELIVERIES: 'DELIVERIES',
    CUSTOM: 'CUSTOM',
    DASHBOARD: 'DASHBOARD',
    MAP: 'MAP',
    PACKING_LISTS: 'PACKING_LISTS',
    SHIPMENT_LABELS: 'SHIPMENT_LABELS'
})
.constant('ACTIONS', {
    C: 'C',
    R: 'R',
    U: 'U',
    D: 'D'
})
.constant('STATUS_OPTIONS', [
    { id: 1, name: 'Active' },
    { id: 0, name: 'In-active' }
])

.constant('YES_NO_OPTIONS', [
    { id: 1, name: 'Yes' },
    { id: 0, name: 'No' }
])

.constant('INPUT_TYPE', {
    label: 1,
    text: 2,
    dropdown: 3,
    checkbox: 4,
    textarea: 5,
    date: 6,
    time: 7,
    dateTime: 8
})
