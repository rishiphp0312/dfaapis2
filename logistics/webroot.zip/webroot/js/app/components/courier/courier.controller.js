angular.module('logistics.courier')
.controller('courierMgtCtrl', ['$scope', '$state', '$rootScope', 'courierService', 'errorService', '$stateParams', '$filter', 'modalService', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, courierService, errorService, $stateParams, $filter, modalService, PAGINATION_DEFAULT) {

    $rootScope.shipmentCode = '';

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    courierService.getCourierList().then(function (data) {
        $scope.courierList = data.couriersList;
        $scope.showNoRecordMsg = data.couriersList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deleteCourier = function (courier) {


        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Courier',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {

            courierService.deleteCourier({ courierId: courier.id }).then(function (res) {

                $scope.courierList = $filter('filter')($scope.courierList, { id: ('!' + courier.id) });
                $scope.showDeleteSucessMsg = true;
                $scope.paginationChanged();

            }, function (err) {
                errorService.show(err);
            });


        });
    }

    $scope.selectedCourier = function (courier) {
        $state.go('logistics.home.courierMgt.overview', { id: courier.id });
    }
} ])

.controller('addModifyCourierCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'courierService', 'modalService', 'commonService', 'onSuccessDialogService', 'filtersService', 'STATUS_OPTIONS',
function ($scope, $rootScope, $stateParams, $state, courierService, modalService, commonService, onSuccessDialogService, filtersService, STATUS_OPTIONS) {

    $rootScope.shipmentCode = '';

    $scope.courierId = $stateParams.id;

    $scope.isModify = $stateParams.id ? true : false;

    if ($scope.isModify) {
        courierService.getCourierDetails({ courierId: $stateParams.id })
        .then(function (data) {
            $scope.courier = data.courierDetails;
        })
    }
    else {
        $scope.courier = '';
    }

    $scope.statusOptions = angular.copy(STATUS_OPTIONS);

    //get all item type list
    courierService.getItemTypeList({ code: 'ItemType' }).then(function (data) {
        $scope.itemTypeList = data.typeList;
    },
    function (err) {
        commonService.error.show(err);
    });

    $scope.saveCourier = function (courier) {


        var msg = $scope.isModify ? 'Courier updated successfully.' : 'Courier saved successfully.';

        courierService.addModifyCourier(courier).then(function (res) {
            if (res) {
                onSuccessDialogService.show(msg, function () {
                    $state.go('logistics.home.courierMgt');
                })
            }
        }, function (err) {
            commonService.error.show(err);
        });
    }
} ])

.controller('CourierOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'courierService',
function ($scope, $rootScope, $stateParams, $state, courierService) {

    $rootScope.shipmentCode = '';

    $scope.courierId = $stateParams.id;

    courierService.getCourierDetails({ courierId: $stateParams.id })
        .then(function (data) {
            $scope.courier = data.courierDetails;
        })
} ])
