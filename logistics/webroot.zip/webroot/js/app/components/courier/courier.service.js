angular.module('logistics.item')
.factory('courierService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var courierService = {};

     courierService.getCourierList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.getCourierList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     courierService.getCourierDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.getCourierDetails, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     courierService.addModifyCourier = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.addModify, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;
     }

     courierService.deleteCourier = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.deleteCourier, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     courierService.getItemTypeList = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.courier.getItemTypeList, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     return courierService;

 } ])