angular.module('logistics.shipmentLabels')
.controller('shipmentLabelsCtrl', ['$scope', '$rootScope', '$state', 'filtersService', 'commonService', 'PAGINATION_DEFAULT', '$stateParams', 'modalService', 'shipmentLabelService',
function ($scope, $rootScope, $state, filtersService, commonService, PAGINATION_DEFAULT, $stateParams, modalService, shipmentLabelService) {

    $rootScope.shipmentCode = '';

    $scope.exportUrl = '';

    $scope.showExportUrl = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    filtersService.getStatusList()
    .then(function (success) {

        $scope.statusList = success.statusList;

        shipmentLabelService.getShipmentList()
        .then(function (success) {
            $scope.ShipmentLabelList = success.shipmentLabelList;

            $scope.showNoRecordMsg = $scope.ShipmentLabelList.length == 0 ? true : false;
            $scope.paginationChanged();
            $scope.pagination.currentPage = $stateParams.page || 1;
        }, function (err) {
            commonService.error.show(err);
        })

    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.filter = {
        status: '',
        area: [],
        location: '',
        code: ''
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

} ])
