angular.module('logistics.packages')
.controller('packagesCtrl', ['$scope', '$state', '$rootScope', '$stateParams', 'packagesService', 'modalService', '$filter', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, $stateParams, packagesService, modalService, $filter, PAGINATION_DEFAULT) {

    $rootScope.shipmentCode = $stateParams.shipmentCode;

    $scope.shipmentCode = $stateParams.shipmentCode;

    packagesService.getPackageList({ shipCode: $scope.shipmentCode }).then(function (data) {
        $scope.packagesList = data.packagesList;

        $scope.showNoRecordMsg = data.packagesList.length == 0 ? true : false;
        $scope.paginationChanged();
        $scope.pagination.currentPage = $stateParams.page || 1;

    }, function (err) {
        errorService.error.show(err);
    });

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }


    $scope.packageSelected = function (package) {
        $state.go('logistics.home.shipment.packages.overview', { packageCode: package.code });
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deletePackage = function (package) {

        $scope.packageId = package.id;

        var data = {
            packageId: $scope.packageId
        }

        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Packages',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {
            packagesService.deletePackage(data)
            .then(function (res) {
                $scope.packagesList = $filter('filter')($scope.packagesList, { id: ('!' + $scope.packageId) });
                $scope.packageId = '';
                $scope.showDeleteSucessMsg = true;
                $scope.paginationChanged();
            }, function (err) {
                errorService.show(err);
            });

        });
    }

} ])

.controller('addModifyPackageCtrl', ['$scope', '$state', '$rootScope', '$stateParams', 'packagesService', '$filter', 'commonService', 'onSuccessDialogService',
function ($scope, $state, $rootScope, $stateParams, packagesService, $filter, commonService, onSuccessDialogService) {

    $rootScope.shipmentCode = $stateParams.shipmentCode;

    $scope.shipmentCode = $stateParams.shipmentCode;

    $scope.packageCode = $stateParams.packageCode;

    $scope.packageObj = {
        shipmentId: '',
        shipmentCode: $stateParams.shipmentCode,
        packageId: '',
        packageCode: '',
        type: '',
        weight: '',
        items: [{
            itemId: '',
            itemCode: '',
            quantity: ''
        }]
    };

    $scope.modifyPackage = $stateParams.packageCode ? true : false;

    if ($scope.modifyPackage) {
        packagesService.getPackageDetails({ packageCode: $stateParams.packageCode })
        .then(function (data) {
            $scope.packageObj = data.packageDetails;
        })
    } else {
        packagesService.generatePackageCode({ shipCode: $stateParams.shipmentCode })
        .then(function (data) {
            if ($scope.packageObj.packageCode == undefined || $scope.packageObj.shipmentId) {
                $scope.packageObj = {
                    packageCode: '',
                    shipmentId: ''
                }
            }
            $scope.packageObj.packageCode = data.pkgCodeDetails.packageCode;
            $scope.packageObj.shipmentId = data.pkgCodeDetails.shipmentId;
        },
        function (err) {
            commonService.error.show(err);
        })
    }

    //get all items list
    packagesService.getItemsList().then(function (data) {
        $scope.itemsList = data.itemsList;
    },
    function (err) {
        commonService.error.show(err);
    });

    //get all package type list
    packagesService.getPackageTypeList({ code: 'PackageType' }).then(function (data) {

        $scope.packageTypeList = data.typeList;
    },
    function (err) {
        commonService.error.show(err);
    });

    // Add new item to the package
    $scope.addNewItem = function () {
        $scope.packageObj.items.push({
            itemCode: '',
            itemName: '',
            quantity: ''
        });
    }

    //delete item from the package
    $scope.deleteItem = function (index) {
        $scope.packageObj.items.splice(index, 1);
    }

    $scope.savePackage = function (package) {

        $scope.emptyItemsList = false;

        $scope.packageObj = package;

        if ($scope.packageObj.items.length >= 1) {

            if ($scope.packageObj.items.length == 1) {

                if ($scope.packageObj.items[0].itemCode == undefined || $scope.packageObj.items[0].itemCode == '') {

                    $scope.emptyItemsList = true;
                    return;
                }
            }
            var msg = $scope.modifyPackage ? 'Package updated successfully.' : 'Package added successfully.';
            packagesService.addModifyPackage(package)
        .then(function (res) {
            if (res) {
                onSuccessDialogService.show(msg, function () {
                    $state.go('logistics.home.shipment.packages', { shipmentCode: $rootScope.shipmentCode });
                })
            }
        }, function (err) {
            commonService.error.show(err);
        });
        }
        else {
            $scope.emptyItemsList = true;
        }
    }
    $scope.updateItem = function (packageContent) {
        var item = JSON.parse(packageContent.item);
        packageContent.itemCode = item.code;
        packageContent.itemId = item.id;
    }

} ])

.controller('packageOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'packagesService', 'commonService',
function ($scope, $rootScope, $stateParams, $state, packagesService, commonService) {

    $rootScope.shipmentCode = $stateParams.shipmentCode;

    $scope.packageCode = $stateParams.packageCode;

    packagesService.getPackageDetails({ packageCode: $stateParams.packageCode })
        .then(function (data) {
            $scope.package = data.packageDetails;
        })
} ])
