angular.module('logistics.packages')
.factory('packagesService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var packagesService = {};

     packagesService.getPackageList = function (data) {

         var deferred = $q.defer();
         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.getPackageList, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }


     packagesService.getPackageTypeList = function (data) {

         var deferred = $q.defer();
         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.getPackageTypeList, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     packagesService.getItemsList = function () {

         var deferred = $q.defer();
         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.getItemsList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     packagesService.deletePackage = function (data) {

         var deferred = $q.defer();
          $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.deletePackage, data))
         .success(function (res) {
         if (res.success) {
             deferred.resolve(res.success);
         } else {
             deferred.reject(res.err);
         }        
         })
       
         return deferred.promise;
     }

     packagesService.getPackageDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.getPackageDetails, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     packagesService.addModifyPackage = function (data) {

         var deferred = $q.defer();
         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.addModifyPackage, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;

     }

     packagesService.generatePackageCode = function (data) {

         var deferred = $q.defer();
         $http(commonService.createHttpRequestObject(SERVICE_CALL.packages.generatePackageCode, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })
         return deferred.promise;
     }

     return packagesService;

 } ])