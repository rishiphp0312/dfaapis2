angular.module('logistics.subscriptions')
.controller('subscriptionsCtrl', ['$scope', '$state', '$rootScope', 'subscriptionsService', 'errorService', '$stateParams', '$filter', 'modalService', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, subscriptionsService, errorService, $stateParams, $filter, modalService, PAGINATION_DEFAULT) {

    $rootScope.shipmentCode = '';

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    subscriptionsService.getSubscriptionList().then(function (data) {
        $scope.subscriptionList = data.subscriptionList;
        $scope.showNoRecordMsg = data.subscriptionList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deleteSubscription = function (data) {

        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Subscription',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {

            subscriptionsService.deleteSubscription({ id: data.id }).then(function (res) {

                $scope.subscriptionList = $filter('filter')($scope.subscriptionList, { id: ('!' + data.id) });
                $scope.showDeleteSucessMsg = true;
                $scope.paginationChanged();

            }, function (err) {
                errorService.show(err);
            });


        });
    }

    $scope.selectedSubscription = function (data) {
        $state.go('logistics.home.subscription.overview', { id: data.id });
    }
} ])

.controller('addModifySubscriptionCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'subscriptionsService', 'modalService', 'commonService', 'onSuccessDialogService', 'filtersService', 'STATUS_OPTIONS',
function ($scope, $rootScope, $stateParams, $state, subscriptionsService, modalService, commonService, onSuccessDialogService, filtersService, STATUS_OPTIONS) {

    $rootScope.shipmentCode = '';

    $scope.subsId = $stateParams.id;

    $scope.isModify = $stateParams.id ? true : false;


    if ($scope.isModify) {
        subscriptionsService.getSubscriptionDetails({ id: $stateParams.id })
        .then(function (data) {
            $scope.subscription = data.subscriptionDetails;
            $scope.subscription.area = [{
                id: data.subscriptionDetails.areaId,
                fields: {
                    aname: data.subscriptionDetails.areaName
                }
            }]
        })
    }

    $scope.statusOptions = angular.copy(STATUS_OPTIONS);

    $scope.prefferedAlertList = [
    { id: 1, name: 'Yes' },
    { id: 0, name: 'No' }
    ]

    filtersService.getAreaList()
    .then(function (success) {
        $scope.areaList = success.areaList;

    }, function (err) {
        commonService.error.show(err);
    });

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.saveSubscription = function (data) {

        $scope.subscription = data;
        if (data.area.length > 0) {
            $scope.subscription.areaId = data.area[0].id;
        }

        var msg = $scope.isModify ? 'Subscription updated successfully.' : 'Subscription saved successfully.';

        subscriptionsService.saveSubscription($scope.subscription).then(function (res) {
            if (res) {
                onSuccessDialogService.show(msg, function () {
                    $state.go('logistics.home.subscription');
                })
            }
        }, function (err) {
            commonService.error.show(err);
        });
    }
} ])

.controller('subscriptionOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'subscriptionsService',
function ($scope, $rootScope, $stateParams, $state, subscriptionsService) {

    $rootScope.shipmentCode = '';

    $scope.sId = $stateParams.id;

    subscriptionsService.getSubscriptionDetails({ id: $stateParams.id })
        .then(function (data) {
            $scope.subscription = data.subscriptionDetails;
        })
} ])
