angular.module('logistics.subscriptions')
.factory('subscriptionsService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var subscriptionsService = {};

     subscriptionsService.getSubscriptionList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.subscriptions.getSubscriptionList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     subscriptionsService.getSubscriptionDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.subscriptions.getSubscriptionDetails, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     subscriptionsService.saveSubscription = function (details) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.subscriptions.addModify, details))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;
     }

     subscriptionsService.deleteSubscription = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.subscriptions.deleteSubscription, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     return subscriptionsService;

 } ])