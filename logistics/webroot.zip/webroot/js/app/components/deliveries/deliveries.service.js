angular.module('logistics.deliveries')
.factory('deliveriesService', ['$http', '$q', 'SERVICE_CALL', 'commonService', 'Upload',
function ($http, $q, SERVICE_CALL, commonService, Upload) {

    var deliveriesService = {};

    deliveriesService.getShipmentList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.deliveries.getShipmentList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    deliveriesService.getDeliveryDetails = function (data) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.deliveries.getDeliveryDetails, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    deliveriesService.saveDelivery = function (data, file) {

        var deferred = $q.defer();

        var data = {
            url: commonService.createHttpRequestObject(SERVICE_CALL.deliveries.saveDelivery).url,
            fields: data,
            sendFieldsAs: 'form'
        }

        if (file) {
            data['file'] = file;
        }

        Upload.upload(data)
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }
    return deliveriesService;

} ])