angular.module('logistics.deliveries')
.controller('deliveriesCtrl', ['$scope', '$rootScope', '$state', 'deliveriesService', 'commonService', 'PAGINATION_DEFAULT', '$stateParams', 'modalService', '$filter', 'filtersService',
function ($scope, $rootScope, $state, deliveriesService, commonService, PAGINATION_DEFAULT, $stateParams, modalService, $filter, filtersService) {

    $rootScope.shipmentCode = '';

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    filtersService.getStatusList()
    .then(function (success) {

        $scope.statusList = success.statusList;

        deliveriesService.getShipmentList()
        .then(function (success) {
            $scope.deliveryList = success.deliveryList;

            $scope.showNoRecordMsg = $scope.deliveryList.length == 0 ? true : false;
            $scope.paginationChanged();
            $scope.pagination.currentPage = $stateParams.page || 1;
        }, function (err) {
            commonService.error.show(err);
        })

    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.filter = {
        status: '',
        area: [],
        locations: '',
        code: ''
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.shipmentSelected = function (shipment) {
        $state.go('logistics.home.deliveries.modify', { id: shipment.deliveryId });
    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

} ])

.controller('modifyDeliveryCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'deliveriesService', 'commonService', 'filtersService', 'onSuccessDialogService',
function ($scope, $rootScope, $stateParams, $state, deliveriesService, commonService, filtersService, onSuccessDialogService) {

    $scope.deliveryId = $stateParams.id;

    $scope.photo;

    deliveriesService.getDeliveryDetails({ deliveryId: $scope.deliveryId })
        .then(function (data) {
            $scope.delivery = data.deliveryDetails;            
        })

    filtersService.getStatusList().then(function (success) {
        $scope.statusList = success.statusList;
    }, function (err) {
        commonService.error.show(err);
    })

    $scope.saveDelivery = function (delivery) {

        $scope.delivery = delivery;
        $scope.delivery['id'] = $stateParams.id;
        deliveriesService.saveDelivery($scope.delivery, $scope.photo ? $scope.photo[0] : '')
        .then(function (res) {
            onSuccessDialogService.show('Delivery updated successfully', function () {

                $state.go('logistics.home.deliveries');
            })
        }, function (err) {
            commonService.error.show(err);
        });

    }

} ])
