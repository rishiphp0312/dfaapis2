angular.module('logistics.map')
.controller('mapsCtrl', ['$scope', '$rootScope', 'commonService', 'mapsService', 'filtersService', '$filter',
function ($scope, $rootScope, commonService, mapsService, filtersService, $filter) {

    $rootScope.shipmentCode = '';

    $scope.filter = {
        shipment: '',
        area: [],
        locations: '',
        shipmentCode: ''
    }

    $scope.showDetails = true;

    $scope.connectPoints = true;

    mapsService.getShipmentList()
    .then(function (success) {
        $scope.shipmentList = success.dashboardshipmentList;
        $scope.filteredShipmentList = success.dashboardshipmentList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.$watch('filter', function (newValue) {
        var tempShipmentList = $filter('filter')($scope.shipmentList, { shipmentId: ($scope.filter.shipment || ''), areaId: ($scope.filter.area.length > 0 ? $scope.filter.area[0].id : ''), locationId: ($scope.filter.location || '') }, $scope.exceptEmptyComparator);

        tempShipmentList = $filter('filter')(tempShipmentList, { shipmentCode: $scope.filter.shipmentCode });

        $scope.filteredShipmentList = tempShipmentList;

    }, true)

} ])