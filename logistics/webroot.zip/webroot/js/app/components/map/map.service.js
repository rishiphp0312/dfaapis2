angular.module('logistics.map')
.factory('mapsService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {

    var mapService = {};

    mapService.getShipmentList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.map.getShipmentList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    return mapService;

} ])