angular.module('logistics.item')
.factory('itemService', ['$http', '$q', '$filter', 'SERVICE_CALL', 'commonService',
 function ($http, $q, $filter, SERVICE_CALL, commonService) {

     var itemService = {};

     itemService.getItemsList = function () {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.items.getItemsList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     itemService.getItemDetails = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.items.getItemDetails, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     itemService.getItemTypeList = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.items.getItemTypeList, data))
        .success(function (res) {
            if (res.success) {

                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }     

     itemService.addModifyItem = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.items.addModifyItem, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;
     }

     itemService.deleteItem = function (data) {

         var deferred = $q.defer();

         $http(commonService.createHttpRequestObject(SERVICE_CALL.items.deleteItem, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

         return deferred.promise;

     }

     return itemService;

 } ])