angular.module('logistics.item')
.controller('itemMgtCtrl', ['$scope', '$state', '$rootScope', 'itemService', 'errorService', '$stateParams', '$filter', 'modalService', 'PAGINATION_DEFAULT',
function ($scope, $state, $rootScope, itemService, errorService, $stateParams, $filter, modalService, PAGINATION_DEFAULT) {

    $rootScope.shipmentCode = '';

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    itemService.getItemsList().then(function (data) {
        $scope.itemsList = data.itemList;
        $scope.showNoRecordMsg = data.itemList.length == 0 ? true : false;
        $scope.paginationChanged();

        $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        errorService.show(err);
    });

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.deleteItem = function (item) {

        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Items',
            bodyText: 'Are you sure you want to delete this record.'
        })
        .then(function (result) {

            itemService.deleteItem({ itemId: item.id }).then(function (res) {

                $scope.itemsList = $filter('filter')($scope.itemsList, { id: ('!' + item.id) });
                $scope.showDeleteSucessMsg = true;
                $scope.paginationChanged();

            }, function (err) {
                errorService.show(err);
            });


        });
    }

    $scope.selectedItem = function (item) {
        $state.go('logistics.home.itemMgt.overview', { id: item.id });
    }

} ])

.controller('addModifyItemCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'itemService', 'modalService', 'commonService', 'onSuccessDialogService', 'filtersService', 'STATUS_OPTIONS',
function ($scope, $rootScope, $stateParams, $state, itemService, modalService, commonService, onSuccessDialogService, filtersService, STATUS_OPTIONS) {

    $rootScope.shipmentCode = '';

    $scope.itemId = $stateParams.id;

    $scope.isModify = $stateParams.id ? true : false;


    if ($scope.isModify) {
        itemService.getItemDetails({ itemId: $stateParams.id })
        .then(function (data) {
            $scope.item = data.itemDetails;
        })
    }

    $scope.statusOptions = angular.copy(STATUS_OPTIONS);

   
    //get all item type list
    itemService.getItemTypeList({ code: 'ItemType' }).then(function (data) {

        $scope.itemTypeList = data.typeList;
    },
    function (err) {
        commonService.error.show(err);
    });


    $scope.saveItem = function (itemDetails) {


        var msg = $scope.isModify ? 'Item updated successfully.' : 'Item saved successfully.';

        itemService.addModifyItem(itemDetails).then(function (res) {
            if (res) {
                onSuccessDialogService.show(msg, function () {
                    $state.go('logistics.home.itemMgt');
                })
            }
        }, function (err) {
            commonService.error.show(err);
        });
    }
} ])

.controller('itemOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'itemService',
function ($scope, $rootScope, $stateParams, $state, itemService) {

    $rootScope.shipmentCode = '';

    $scope.itemId = $stateParams.id;

    itemService.getItemDetails({ itemId: $stateParams.id })
        .then(function (data) {
            $scope.item = data.itemDetails;
        })
} ])