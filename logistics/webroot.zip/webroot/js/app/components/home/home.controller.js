angular.module('logistics.home')
.controller('homeCtrl', [function () {

} ]);