angular.module('logistics.location')
.factory('locationService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {

    var locationService = {};

    locationService.getLocationList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.location.getLocationList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    locationService.deleteLocation = function (data) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.location.deleteLocation, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;

    }

    locationService.getLocationDetail = function (data) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.location.getLocationDetail, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    locationService.getLocationType = function (data) {
        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.location.getLocationType, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    locationService.saveLocation = function (data) {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.location.saveLocation, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.success);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    return locationService;

} ])