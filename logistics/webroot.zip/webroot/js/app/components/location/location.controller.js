angular.module('logistics.location')
.controller('locationCtrl', ['$scope', '$rootScope', '$state', 'locationService', 'commonService', 'PAGINATION_DEFAULT', 'modalService', '$filter',
function ($scope, $rootScope, $state, locationService, commonService, PAGINATION_DEFAULT, modalService, $filter) {
    $rootScope.shipmentCode = '';

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    locationService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
        $scope.showNoRecordMsg = (success.locationList.length == 0);
        $scope.paginationChanged();
        // $scope.pagination.currentPage = $stateParams.page || 1;
    }, function (err) {
        commonService.error.show(err);
    })

    $scope.deleteLocation = function (locationId) {
        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Location',
            bodyText: 'Are you sure you want to delete this record?'
        }).then(function (result) {
            confirmDelete(locationId);
        });
    }

    function confirmDelete(locationId) {

        var data = { id: locationId }

        locationService.deleteLocation(data)
        .then(function (success) {

            var deleteIndex;

            angular.forEach($scope.locationList, function (location, index) {
                if (location.id == locationId) {
                    deleteIndex = index;
                }
            })

            if (deleteIndex)
                $scope.locationList.splice(deleteIndex, 1);

            $scope.showDeleteSucessMsg = true;

        }, function (err) {
            commonService.error.show(err);
            $scope.showDeleteSucessMsg = false;
        })

    }

} ])

.controller('locationOverviewCtrl', ['$scope', '$rootScope', '$state', '$stateParams', 'locationService', 'commonService', 'PAGINATION_DEFAULT', 'modalService', '$filter',
function ($scope, $rootScope, $state, $stateParams, locationService, commonService, PAGINATION_DEFAULT, modalService, $filter) {

    $scope.locationId = $stateParams.locationId;

    locationService.getLocationDetail({ id: $scope.locationId })
    .then(function (success) {
        $scope.location = success.locationDetails;
    }, function (err) {
        commonService.error.show(err);
    })


} ])

.controller('addModifyLocationCtrl', ['$scope', '$rootScope', '$state', '$stateParams', 'locationService', 'filtersService', 'commonService', 'PAGINATION_DEFAULT', 'modalService', '$filter', 'INPUT_TYPE', 'STATUS_OPTIONS',
function ($scope, $rootScope, $state, $stateParams, locationService, filtersService, commonService, PAGINATION_DEFAULT, modalService, $filter, INPUT_TYPE, STATUS_OPTIONS) {

    $scope.locationId = $stateParams.locationId || '';

    $scope.location;

    $scope.statusOptions = STATUS_OPTIONS;

    if ($scope.locationId) {
        $scope.isModify = true;
        locationService.getLocationDetail({ id: $scope.locationId })
        .then(function (success) {
            $scope.location = success.locationDetails;
            $scope.locationName = $scope.location.name;
            $scope.location.area = [{
                id: $scope.location.areaId,
                fields: {
                    aname: $scope.location.areaName
                }
            }]
        }, function (err) {
            commonService.error.show(err);
        })
    }

    locationService.getLocationType({ code: 'LocationType' })
    .then(function (success) {
        $scope.locationType = success.typeList;
    }, function (err) {
        commonService.error.show(err);
    })

    filtersService.getAreaList()
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.dropdownProperties.placeholder = '';

    $scope.saveLocation = function () {

        var msg = $scope.isModify ? 'Location updated successfully.' : 'Location added successfully.';

        var data = $scope.location;

        if (data.area && data.area.length > 0) {
            data.areaId = data.area[0].id;
        }

        locationService.saveLocation($scope.location)
        .then(function (success) {
            onSuccessDialogService.show(msg, function () {
                $state.go('logistics.home.location');
            })
        }, function (err) {
            commonService.error.show(err);
        })

    }

    //  $scope.customFields = [{
    //      id: 1,
    //      label: 'Location Classified',
    //      type: 3,
    //      name: 'Location_Classified',
    //      options: [{ id: 1, name: 'Yes' }, { id: 0, name: 'No'}],
    //      isRequired: false,
    //      isUnique: false,
    //      applyToAll: false,
    //      applyToType: [4]
    //  }, {
    //      id: 3,
    //      label: 'Location Second Name',
    //      type: 2,
    //      name: 'Location_Second_Name',
    //      options: [],
    //      isRequired: false,
    //      isUnique: false,
    //      applyToAll: true,
    //      applyToType: []
    //  }, {
    //      id: 2,
    //      label: 'Location Second Name',
    //      type: 5,
    //      name: 'Location_Second_Name',
    //      options: [],
    //      isRequired: false,
    //      isUnique: false,
    //      applyToAll: true,
    //      applyToType: []
    //  }, {
    //      id: 2,
    //      label: 'Location Second Name',
    //      type: 6,
    //      name: 'Location_Second_Name',
    //      options: [],
    //      isRequired: false,
    //      isUnique: false,
    //      applyToAll: true,
    //      applyToType: []
    //  }, {
    //      id: 5,
    //      label: 'Status of Shipment',
    //      type: 4,
    //      name: 'Status_of_Shipment',
    //      options: [
    //	{ id: '', label: 'Required' },
    //	{ id: '', label: 'Not Required' },
    //	{ id: '', label: 'MayBe' }
    //],
    //      required: true / false,
    //      isUnique: true / false,
    //      applyToAll: true,
    //      applyToType: []
    //  }]

    //locationService.getCustomFields()
    //.then(function (success) {
    //    $scope.customFields = success.customFields;
    //}, function (err) {
    //    commonService.error.show(err);
    //})

} ])