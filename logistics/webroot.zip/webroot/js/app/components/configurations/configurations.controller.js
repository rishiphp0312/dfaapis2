angular.module('logistics.configurations')
.controller('configurationsCtrl', ['$scope', '$rootScope', 'commonService', 'configurationsService', '$filter',
function ($scope, $rootScope, commonService, configurationsService, $filter) {

    $rootScope.shipmentCode = '';

    var tabSections = [];

    configurationsService.getConfigurations()
    .then(function (success) {
        $scope.configSettings = success.configurationList;
        angular.forEach($scope.configSettings, function (value, key) {
            tabSections.push({
                id: key,
                title: value.title
            })
        });
    }, function (err) {
        commonService.error.show(err);
    })

    $scope.tabs = tabSections;

    $scope.tabSelected = function (tab) {
        $scope.activeTab = tab.id;
        $scope.saveSuccessful = false;
    }

    $scope.saveConfig = function () {

        var data = $scope.configSettings[$scope.activeTab];

        configurationsService.modifyConfigurations(data)
        .then(function (success) {
            _SYSCONFIG = success.sysConfig;
            $scope.systemConfig = _SYSCONFIG;
            $scope.saveSuccessful = true;
        }, function (err) {
            $scope.saveSuccessful = false;
            commonService.error.show(err);
        })

    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

} ])