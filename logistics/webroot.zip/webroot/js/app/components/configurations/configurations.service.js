angular.module('logistics.configurations')
.factory('configurationsService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {

    var configurationsService = {};

    configurationsService.getConfigurations = function () {
        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.configurations.getConfigurations))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    configurationsService.modifyConfigurations = function (data) {
        
        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.configurations.modifyConfigurations, data))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

    return configurationsService;

} ])