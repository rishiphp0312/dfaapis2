angular.module('logistics.shipment')
.controller('shipmentsCtrl', ['$scope', '$rootScope', '$state', 'shipmentService', 'filtersService', 'commonService', 'modalService', 'PAGINATION_DEFAULT', '$stateParams',
function ($scope, $rootScope, $state, shipmentService, filtersService, commonService, modalService, PAGINATION_DEFAULT, $stateParams) {

    $rootScope.shipmentCode = '';

    $scope.showDeleteSucessMsg = false;

    $scope.pagination = angular.copy(PAGINATION_DEFAULT);

    $scope.setTotalCount = function (arr) {
        if (arr)
            $scope.pagination.totalCount = arr.length;
    }

    filtersService.getStatusList()
    .then(function (success) {
        $scope.statusList = success.statusList;
        shipmentService.getShipmentList()
        .then(function (success) {
            $scope.shipmentList = success.shipmentList;
            angular.forEach($scope.shipmentList, function (shipment) {
                angular.forEach($scope.statusList, function (status) {
                    if (shipment.statusId == status.id) {
                        shipment.status = status.name;
                        shipment.statusColorCode = status.colorCode;
                    }
                })
            })
            $scope.showNoRecordMsg = $scope.shipmentList.length == 0 ? true : false;
            $scope.paginationChanged();
            $scope.pagination.currentPage = $stateParams.page || 1;
        }, function (err) {
            commonService.error.show(err);
        })
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    });

    filtersService.getAreaList(true)
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    $scope.filter = {
        status: '',
        area: [],
        locations: '',
        shipmentCode: ''
    }

    $scope.shipmentSelected = function (shipmentCode) {
        $state.go('logistics.home.shipment.overview', { shipmentCode: shipmentCode });
    }

    $scope.paginationChanged = function () {
        var startIndex = $scope.pagination.pageSize * ($scope.pagination.currentPage - 1);
        var endIndex = startIndex + ($scope.pagination.pageSize - 1);
        $scope.pagination.from = startIndex + 1;
        $scope.pagination.to = endIndex + 1;
        // for last page.
        if ($scope.pagination.from < $scope.pagination.totalCount && $scope.pagination.totalCount <= $scope.pagination.to) {
            $scope.pagination.to = $scope.pagination.totalCount;
        }
    }

    $scope.sort = function (header) {
        var sortOrderType = {
            'asc': true,
            'desc': false,
            'none': ''
        }
        if ($scope.sortHeader != header) {
            $scope.sortHeader = header;
            $scope.sortOrder = sortOrderType.none;
        }

        if ($scope.sortOrder == sortOrderType.none)
            $scope.sortOrder = sortOrderType.asc;
        else
            $scope.sortOrder = !$scope.sortOrder;
    }

    $scope.areaTreeViewOptions = filtersService.areaTreeViewOptions();

    $scope.dropdownProperties = filtersService.dropdownProperties();

    $scope.deleteShipment = function (shipmentId) {
        modalService.show({}, {
            closeButtonText: 'Cancel',
            actionButtonText: 'Delete',
            headerText: 'Shipment',
            bodyText: 'Are you sure you want to delete this record?'
        })
        .then(function (result) {
            confirmDelete(shipmentId);
        });
    }

    function confirmDelete(shipmentId) {

        var data = { id: shipmentId };

        shipmentService.deleteShipment(data)
        .then(function (success) {

            var deleteIndex;

            angular.forEach($scope.shipmentList, function (shipment, index) {
                if (shipment.id == shipmentId) {
                    deleteIndex = index;
                }
            })

            if (deleteIndex)
                $scope.shipmentList.splice(deleteIndex, 1);

            $scope.showDeleteSucessMsg = true;
        }, function (err) {
            commonService.error.show(err);
        })

    }

} ])

.controller('addModifyShipmentCtrl', ['$scope', '$rootScope', '$stateParams', '$state', '$filter', 'commonService', 'filtersService', 'shipmentService', 'CALENDER_DATE_OPT', 'CALENDER_FORMAT', 'onSuccessDialogService',
function ($scope, $rootScope, $stateParams, $state, $filter, commonService, filtersService, shipmentService, CALENDER_DATE_OPT, CALENDER_FORMAT, onSuccessDialogService) {

    $rootScope.shipmentCode = $stateParams.shipmentCode || '';

    $scope.isModify = $rootScope.shipmentCode == '' ? false : true;

    $scope.shipment = {
        shipmentCode: '',
        shipFrom: {
            areaId: '',
            locationId: ''
        },
        deliveryPoint: [{
            sequenceNumber: '',
            shipFrom: {
                areaId: '',
                locationId: ''
            },
            shipTo: {
                areaId: '',
                locationId: ''
            },
            courierId: '',
            expectedDate: '',
            confirmationRequired: ''
        }],
        finalDeliveryPoint: {
            sequenceNumber: '',
            shipFrom: {
                areaId: '',
                locationId: ''
            },
            shipTo: {
                areaId: '',
                locationId: ''
            },
            courierId: '',
            expectedDate: '',
            confirmationRequired: ''
        }
    }

    if ($scope.isModify) {
        shipmentService.getShipmentDetails({ shipmentCode: $stateParams.shipmentCode })
        .then(function (success) {

            success.shipmentDetails.shipFrom.area = [{
                id: success.shipmentDetails.shipFrom.areaId,
                fields: {
                    aname: success.shipmentDetails.shipFrom.areaName
                }
            }]

            if (success.shipmentDetails.deliveryPoint == undefined || success.shipmentDetails.deliveryPoint.length == 0) {

                success.shipmentDetails.deliveryPoint = [];

                success.shipmentDetails.deliveryPoint.push({
                    sequenceNumber: '',
                    shipFrom: {
                        areaId: '',
                        locationId: ''
                    },
                    shipTo: {
                        areaId: '',
                        locationId: ''
                    },
                    courierId: '',
                    expectedDate: '',
                    confirmationRequired: ''
                })

            }

            angular.forEach(success.shipmentDetails.deliveryPoint, function (deliveryPoint) {
                if (deliveryPoint.shipTo.areaId != '') {
                    deliveryPoint.area = [{
                        id: deliveryPoint.shipTo.areaId,
                        fields: {
                            aname: deliveryPoint.shipTo.areaName
                        }
                    }]
                }
            })

            success.shipmentDetails.finalDeliveryPoint.area = [{
                id: success.shipmentDetails.finalDeliveryPoint.shipTo.areaId,
                fields: {
                    aname: success.shipmentDetails.finalDeliveryPoint.shipTo.areaName
                }
            }]

            $scope.shipment = success.shipmentDetails;

        }, function (err) {
            commonService.error.show(err);
        })
    } else {
        shipmentService.generateShipmentCode()
        .then(function (success) {
            $scope.shipment.shipmentCode = success.shipmentCode;
        }, function (err) {
            commonService.error.show(err);
        })
    }

    shipmentService.getConfirmationList()
    .then(function (success) {
        $scope.confirmationList = success.typeList;
    })

    filtersService.getLocationList()
    .then(function (success) {
        $scope.locationList = success.locationList;
    }, function (err) {
        commonService.error.show(err);
    })

    filtersService.getAreaList()
    .then(function (success) {
        $scope.areaList = success.areaList;
    }, function (err) {
        commonService.error.show(err);
    });

    shipmentService.getCourierList()
    .then(function (success) {
        $scope.courierList = success.courierList;
    }, function (err) {
        commonService.error.show(err);
    })

    $scope.areaTreeViewOptions = {
        onDemand: true,
        useICheck: true,
        onDemandOptions: {
            url: commonService.getAreaOnDemandURL(),
            responseDataKey: ['data', 'areaList'],
            requestDataKey: 'returnData'
        },
        selectionOptions: {
            multiSelection: false,
            showCheckBox: false,
            checkBoxClass: '',
            selectedClass: 'nodeSelected'
        },
        nodeOptions: {
            showNodeOpenCloseClass: true,
            nodeOpenClass: 'fa fa-plus',
            nodeCloseClass: 'fa fa-minus',
            showNodeLeafClass: false,
            nodeLeafClass: '',
            showLoader: true,
            loaderClass: 'fa fa-spinner fa-spin'
        },
        labelOptions: {
            fields: [{
                id: 'aname',
                css: '',
                seperator: ''
            }],
            prefix: '',
            suffix: '',
            class: ''
        }
    }

    $scope.dropdownProperties = {
        search: false,
        showSelected: false,
        autoSelect: true
    }

    $scope.addDeliveryPoint = function () {
        $scope.shipment.deliveryPoint.push({
            sequenceNumber: '',
            shipFrom: {
                areaId: '',
                locationId: ''
            },
            shipTo: {
                areaId: '',
                locationId: ''
            },
            courierId: '',
            expectedDate: '',
            confirmationRequired: ''
        })
    }

    $scope.deleteDeliveryPoint = function (index) {
        $scope.shipment.deliveryPoint.splice(index, 1);
    }

    $scope.openCalendar = function ($event, calObj) {
        $event.preventDefault();
        $event.stopPropagation();
        calObj.openCalendar = true;
    }

    $scope.format = CALENDER_FORMAT['dd-MM-yyyy'];

    $scope.dateOptions = CALENDER_DATE_OPT;

    $scope.saveShipment = function () {

        $scope.valid = validateShipment($scope.shipment);

        var msg = $scope.isModify ? 'Shipment updated successfully.' : 'Shipment added successfully.';

        if ($scope.valid) {

            var data = buildShipmentObject($scope.shipment);

            shipmentService.saveShipment(data)
            .then(function (success) {
                onSuccessDialogService.show(msg, function () {
                    $state.go('logistics.home');
                })

            }, function (err) {
                commonService.error.show(err);
            })
        }
    }

    function validateShipment(shipment) {

        var valid = true;
        /* Shipfrom Validation */
        if (shipment.shipFrom.area == undefined || shipment.shipFrom.area.length <= 0) {
            valid = false;
        }

        if (shipment.shipFrom.locationId == undefined || shipment.shipFrom.locationId == '') {
            valid = false;
        }

        if (!checkValidLocation(shipment.shipFrom.area, shipment.shipFrom.locationId)) {
            shipment.shipFrom.locationId = '';
            valid = false;
        }

        /* Final Delivery Validation*/
        if (shipment.finalDeliveryPoint.area == undefined || shipment.finalDeliveryPoint.area.length <= 0) {
            valid = false;
        }

        if (shipment.finalDeliveryPoint.shipTo.locationId == undefined || shipment.finalDeliveryPoint.shipTo.locationId == '') {
            valid = false;
        }

        if (!checkValidLocation(shipment.finalDeliveryPoint.area, shipment.finalDeliveryPoint.shipTo.locationId)) {
            shipment.finalDeliveryPoint.shipTo.locationId = '';
            valid = false;
        }

        if (shipment.finalDeliveryPoint.courierId == undefined || shipment.finalDeliveryPoint.courierId == '') {
            valid = false;
        }

        if (shipment.finalDeliveryPoint.expectedDate == undefined || shipment.finalDeliveryPoint.expectedDate == '') {
            valid = false;
        }

        if (shipment.finalDeliveryPoint.confirmationRequired == undefined || shipment.finalDeliveryPoint.confirmationRequired == '') {
            valid = false;
        }

        /*Delivery Points validations*/
        angular.forEach(shipment.deliveryPoint, function (deliveryPoint) {
            if (!
                ((deliveryPoint.area == undefined || deliveryPoint.area.length <= 0) &&
                (deliveryPoint.shipTo.locationId == undefined || deliveryPoint.shipTo.locationId == '') &&
                (deliveryPoint.shipTo.courierId == undefined || deliveryPoint.shipTo.courierId == '') &&
                (deliveryPoint.shipTo.expectedDate == undefined || deliveryPoint.shipTo.expectedDate == '') &&
                (deliveryPoint.shipTo.confirmationRequired == undefined || deliveryPoint.shipTo.confirmationRequired == ''))
            ) {

                deliveryPoint.checkForValidation = true;

                if (deliveryPoint.area == undefined || deliveryPoint.area.length <= 0) {
                    valid = false;
                }

                if (deliveryPoint.shipTo.locationId == undefined || deliveryPoint.shipTo.locationId == '') {
                    valid = false;
                }

                if (!checkValidLocation(deliveryPoint.area, deliveryPoint.shipTo.locationId)) {
                    deliveryPoint.shipTo.locationId = '';
                    valid = false;
                }

                if (deliveryPoint.courierId == undefined || deliveryPoint.courierId == '') {
                    valid = false;
                }
                if (deliveryPoint.expectedDate == undefined || deliveryPoint.expectedDate == '') {
                    valid = false;
                }

                if (deliveryPoint.confirmationRequired == undefined || deliveryPoint.confirmationRequired == '') {
                    valid = false;
                }

            } else {
                deliveryPoint.checkForValidation = false;
            }
        })

        return valid;

    }

    function checkValidLocation(area, locationId) {

        var found = false;

        if (area && area.length > 0 && locationId && locationId != '') {
            angular.forEach($scope.locationList, function (location) {
                if (location.id == locationId && location.areaId == area[0].id) {
                    found = true;
                }
            })
        }

        return found;
    }

    function buildShipmentObject(obj) {

        var shipment = angular.copy(obj);

        shipment.shipFrom.areaId = shipment.shipFrom.area[0].id;

        var deliveryPoints = [];

        var index = 0;

        // set delivery Points.
        angular.forEach(shipment.deliveryPoint, function (deliveryPoint) {

            if (deliveryPoint.checkForValidation) {
                deliveryPoint.sequenceNumber = index + 1;
                deliveryPoint.shipTo.areaId = deliveryPoint.area[0].id;
                deliveryPoint.shipFrom = deliveryPoint.shipFrom || {};
                // first index
                if (index == 0) {
                    deliveryPoint.shipFrom.areaId = shipment.shipFrom.areaId;
                    deliveryPoint.shipFrom.locationId = shipment.shipFrom.locationId;
                } else {
                    deliveryPoint.shipFrom.areaId = shipment.deliveryPoint[index - 1].shipTo.areaId;
                    deliveryPoint.shipFrom.locationId = shipment.deliveryPoint[index - 1].shipTo.locationId;
                }

                deliveryPoint.expectedDate = $filter('date')(deliveryPoint.expectedDate, 'yyyy-MM-dd');

                deliveryPoints.push(deliveryPoint);

                index = index + 1;
            }

        })

        shipment.deliveryPoint = deliveryPoints;

        shipment.finalDeliveryPoint.sequenceNumber = shipment.deliveryPoint.length + 1;

        shipment.finalDeliveryPoint.shipTo.areaId = shipment.finalDeliveryPoint.area[0].id;

        if (shipment.finalDeliveryPoint.shipFrom == undefined) {
            shipment.finalDeliveryPoint['shipFrom'] = {
                areaId: '',
                locationId: ''
            };
        }
        shipment.finalDeliveryPoint.shipFrom.areaId = shipment.deliveryPoint.length > 0 ? shipment.deliveryPoint[shipment.deliveryPoint.length - 1].shipTo.areaId : shipment.shipFrom.areaId;

        shipment.finalDeliveryPoint.shipFrom.locationId = shipment.deliveryPoint.length > 0 ? shipment.deliveryPoint[shipment.deliveryPoint.length - 1].shipTo.locationId : shipment.shipFrom.locationId;

        shipment.finalDeliveryPoint.expectedDate = $filter('date')(shipment.finalDeliveryPoint.expectedDate, 'yyyy-MM-dd');

        return shipment;

    }

} ])

.controller('shipmentOverviewCtrl', ['$scope', '$rootScope', '$stateParams', '$state', 'shipmentService', 'commonService',
function ($scope, $rootScope, $stateParams, $state, shipmentService, commonService) {

    $rootScope.shipmentCode = $stateParams.shipmentCode;

    shipmentService.getShipmentDetails({ shipmentCode: $stateParams.shipmentCode })
    .then(function (success) {
        $scope.shipment = success.shipmentDetails;
    }, function (err) {
        commonService.error.show(err);
    })

} ])