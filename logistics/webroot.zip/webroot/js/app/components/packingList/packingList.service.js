angular.module('logistics.packingList')
.factory('packingListService', ['$http', '$q', 'SERVICE_CALL', 'commonService',
function ($http, $q, SERVICE_CALL, commonService) {

    var packingListService = {};

    packingListService.getPackingList = function () {

        var deferred = $q.defer();

        $http(commonService.createHttpRequestObject(SERVICE_CALL.packingLabel.getPackingList))
        .success(function (res) {
            if (res.success) {
                deferred.resolve(res.data);
            } else {
                deferred.reject(res.err);
            }
        })

        return deferred.promise;
    }

       return packingListService;

} ])