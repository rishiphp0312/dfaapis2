angular.module('packageTracker', [])

.directive('packageTracker', [function () {

    return {
        restrict: 'E',
        replace: true,
        scope: {
            ngModel: '='
        },
        link: function (scope, element, attrs, controller) {

            var containerCss = attrs['canvasStyle'] || '';

            var canvasContainer = '<div class="canvas-container" style="' + containerCss + '"></div>'

            element.append(canvasContainer);

            scope.$watch('ngModel', function (newValue) {
                if (newValue) {
                    drawCanvas(newValue);
                }
            });

            function drawCanvas(points) {

                var maxRadius = parseInt(attrs['trackerMaxRadius'] || 30);

                var padding = parseInt(attrs['trackerPadding'] || 10);

                var yOffset = parseInt(attrs['trackerYOffset'] || 12);

                var canvasContainer = element.find('.canvas-container');

                var canvasWidth = canvasContainer[0].offsetWidth;

                var canvasHeight = canvasContainer[0].offsetHeight;

                var canvasHtml = '<canvas width="' + canvasWidth + '" height="' + canvasHeight + ' "></canvas>';

                canvasContainer.append(canvasHtml);

                var canvasElement = element.find('.canvas-container > canvas')[0];

                if (canvasElement.getContext) {

                    var diameter = (canvasElement.width - (2 * padding)) / (points.length + (points.length - 1));

                    var connectorLength = diameter;

                    if ((canvasElement.width - (2 * padding)) > (maxRadius * 2) * (points.length + (points.length - 1))) {

                        diameter = maxRadius * 2;

                        connectorLength = (canvasElement.width - (2 * padding) - (points.length * diameter)) / (points.length - 1);

                    }

                    var radius = diameter / 2;

                    var ctx = canvasElement.getContext('2d');

                    angular.forEach(points, function (point, index) {

                        ctx.beginPath();

                        var xCircle = (padding + (index * diameter) + (index * connectorLength) + radius);

                        var y = (canvasElement.height / 2) - yOffset;

                        ctx.arc(xCircle, y, radius, 0, 2 * Math.PI);
                        ctx.fillStyle = point.statusColor || '#fff';
                        ctx.fill();
                        ctx.stroke();

                        ctx.font = "normal 12px sans-serif";
                        ctx.strokeText(point.locationName, xCircle - radius, y + radius + 5 + yOffset, diameter);

                        if (index < points.length - 1) {
                            ctx.moveTo(xCircle + radius, y)
                            ctx.lineTo(xCircle + radius + connectorLength, y);
                            ctx.stroke();
                        }

                        ctx.closePath();

                    })



                }

            }

        }
    }
} ])