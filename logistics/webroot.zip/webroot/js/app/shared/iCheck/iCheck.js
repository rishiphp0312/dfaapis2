angular.module('iCheck', [])
.directive('iCheck', ['$timeout', '$parse', function ($timeout, $parse) {
    return {
        scope: {
            ngClick: '&',
            ngChecked: '=',
            ngModel: '=',
            clickParams: '='
        },
        link: function (scope, element, $attrs) {
            return $timeout(function () {

                var value;

                value = $attrs['value'];

                // check if ng Model - ng Model will be given preference.
                if ($attrs['ngModel'] != undefined) {
                    scope.$watch('ngModel', function (newValue) {
                        $(element).iCheck('update');
                    });

                } else if ($attrs['ngChecked'] != undefined) {
                    scope.$watch('ngChecked', function (newValue) {
                        if (newValue) {
                            value = true;
                        } else {
                            value = false;
                        }
                        $(element).iCheck('update');
                    });
                }

                return $(element).iCheck({
                    checkboxClass: 'icheckbox_minimal-grey icheck-input',
                    radioClass: 'iradio_minimal-grey icheck-input'
                }).on('ifChanged', function (event) {
                    if ($(element).attr('type') === 'checkbox' && $attrs['ngModel']) {
                        scope.$apply(function () {
                            return scope.ngModel = event.target.checked;
                        });
                    }
                    if ($(element).attr('type') === 'radio' && $attrs['ngModel']) {
                        return scope.$apply(function () {
                            return scope.ngModel = value;
                        });
                    }
                }).on('ifClicked', function (event) {
                    if ($attrs['ngClick']) {
                        scope.ngClick(scope.clickParams)
                    }
                });
            })
        }
    };
} ])
