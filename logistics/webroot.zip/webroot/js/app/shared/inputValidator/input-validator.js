angular.module('inputValidator', [])
.directive('allowNumeric', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {
            ngModel.$parsers.push(function (inputValue) {

                // this next if is necessary for when using ng-required on your input. 
                // In such cases, when a letter is typed first, this parser will be called
                // again, and the 2nd time, the value will be undefined
                if (inputValue == undefined)
                    return '';

                var regex = /(\d+\.?\d*)/;

                var cleanValue = inputValue.match(regex);

                if (cleanValue == null) {
                    cleanValue = '';
                } else {
                    cleanValue = cleanValue[0];
                }

                if (inputValue !== cleanValue) {
                    ngModel.$setViewValue(cleanValue);
                    ngModel.$render();
                }

                return cleanValue;

            });

        }
    }
})
.directive('inputValidator', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            inputValidator: '='
        },
        link: function (scope, element, attrs, ngModel) {

            //checks if dataType is Int
            function isInt(n) {
                return Number(n) === parseInt(n) && n % 1 === 0;
            }

            //checks if dataType is Float
            function isFloat(n) {
                return parseFloat(n) === Number(n) && n % 1 !== 0;
            }

            //converts a given string to int or float.
            function convertToIntOrFloat(val) {
                return isInt(val) ? parseInt(val) : isFloat(val) ? parseFloat(val) : undefined;
            }

            ngModel.$parsers.push(function (value) {

                if (value == undefined) {
                    return '';
                }

                if (scope.inputValidator == undefined) {
                    scope.inputValidator = {
                        isTextual: false
                    }
                }

                var isTextual = scope.inputValidator.isTextual || false;

                if (!isTextual && value != '') {
                    if (isInt(value) || isFloat(value)) {
                        ngModel.$setValidity('isNumeric', true);
                    } else {
                        ngModel.$setValidity('isNumeric', false);
                    }
                }

                var currentValue = convertToIntOrFloat(value);

                var minValue = convertToIntOrFloat(scope.inputValidator.minimumValue);

                if (angular.isDefined(minValue) && angular.isDefined(currentValue)) {
                    if (currentValue >= minValue) {
                        ngModel.$setValidity('minValue', true);
                    } else {
                        ngModel.$setValidity('minValue', false);
                    }
                }

                var maxValue = convertToIntOrFloat(scope.inputValidator.maximumValue);

                if (angular.isDefined(maxValue) && angular.isDefined(currentValue)) {
                    if (currentValue <= maxValue) {
                        ngModel.$setValidity('maxValue', true);
                    } else {
                        ngModel.$setValidity('maxValue', false);
                    }
                }


                return value;

            });

        }
    }
})
.directive('validateData', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            data: '=validateData'
        },
        link: function (scope, element, attrs, ngModel) {
            scope.$watch('data', function () {
                /*
                    if 
                        data is marked for deletion then do not validate
                    else
                        if data Nid is present
                            both data value and src should be present
                        else if data Nid is not present
                            if 
                                both data value and src are empty, data is valid
                            else if
                                one from data valur or source is present, data is invalid
                            else
                                data is valid
                */
                if (scope.data.markedForDelete == true) {
                    ngModel.$setValidity('dataValid', true);
                } else {
                    if (scope.data.dNid == '') {
                        if (scope.data.dv == '' && scope.data.srcNid == '') {
                            ngModel.$setValidity('dataValid', true);
                        } else if (scope.data.dv == '' || scope.data.srcNid == '') {
                            ngModel.$setValidity('dataValid', false);
                        } else {
                            ngModel.$setValidity('dataValid', true);
                        }
                    } else {
                        if (scope.data.dv != '' && scope.data.srcNid != '') {
                            ngModel.$setValidity('dataValid', true);
                        } else {
                            ngModel.$setValidity('dataValid', false);
                        }
                    }
                }

            }, true);
        }

    }
})