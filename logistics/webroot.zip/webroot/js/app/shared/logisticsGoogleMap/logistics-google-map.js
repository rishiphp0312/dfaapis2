angular.module('logisticsGoogleMap', [])
.directive('logisticsGoogleMap', ['$filter', function ($filter) {
    return {
        restrict: 'A',
        scope: {
            ngModel: '=',
            connectPoints: '=',
            showDetails: '='
        },
        link: function (scope, element, attrs, controller) {

            var markers = [];

            var map;

            var flightPaths = [];

            var defaultCenterLatLng = { lng: 76.321, lat: 26.365 };

            scope.$watch('ngModel', function (newValue) {
                if (newValue) {
                    createMap();
                }
            }, true)

            scope.$watch('connectPoints', function (newValue) {
                if (newValue != undefined && map && markers) {
                    setFlightPaths(map, markers);
                }
            })

            function createMap(mapOptions) {

                var mapOptions = {
                    center: defaultCenterLatLng,
                    zoom: 4,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    mapTypeControl: false,
                    streetViewControl: false,
                    rotateControl: false
                };

                markers = getMarkerCoordinates();

                if (markers.length > 0) {
                    mapOptions.center = markers[0].coordinates;
                }

                map = new google.maps.Map(element[0], mapOptions);

                setMarkers(map, markers);

                if (scope.connectPoints) {
                    setFlightPaths(map, markers);
                }


            }

            function getMarkerCoordinates() {
                var markers = [];
                angular.forEach(scope.ngModel, function (model) {
                    if (model.lat != undefined && model.lng != undefined &&
                        model.lat != '' && model.lng != '') {
                        markers.push({
                            coordinates: {
                                lat: parseFloat(model.lat),
                                lng: parseFloat(model.lng)
                            },
                            title: model.locationName,
                            statusColor: model.statusColor,
                            status: model.statusName,
                            estimatedDate: model.estimatedDate
                        })
                    }
                })
                return markers;
            }

            function setMarkers(map, markers) {

                var infowindow = new google.maps.InfoWindow({
                    content: ""
                });

                for (i = 0; i < markers.length; i++) {

                    var infoWindowHTML = '';

                    infoWindowHTML = '<div>' +
                        '<b> ' + markers[i].title + ' </b> <br>' +
                        '<span style="font-size: 12px;">' + markers[i].status + '</span> <br>' +
                        '<span style="font-size: 12px;">' + (markers[i].estimatedDate ? $filter('date')(markers[i].estimatedDate, 'dd-MMM-yyyy') : '') + '</span>' +
                    '</div>'

                    var marker = new google.maps.Marker({
                        position: markers[i].coordinates,
                        map: map,
                        title: markers[i].title,
                        content: infoWindowHTML
                    });

                    marker.addListener('click', function () {
                        if (scope.showDetails) {
                            infowindow.setContent(this.content);
                            infowindow.open(map, this);
                        }
                    });

                }
            }

            function setFlightPaths(map, markers) {

                if (flightPaths.length > 0) {

                    angular.forEach(flightPaths, function (flightPath) {

                        if (scope.connectPoints) {
                            flightPath.setMap(map);
                        } else {
                            flightPath.setMap(null);
                        }

                    })

                } else {
                    for (i = 0; i < markers.length - 1; i++) {

                        var flightPlanCoordinates = [
                            markers[i].coordinates,
                            markers[i + 1].coordinates
                        ]

                        var lineSymbol = {
                            path: google.maps.SymbolPath.FORWARD_OPEN_ARROW
                        };

                        var flightPath = new google.maps.Polyline({
                            path: flightPlanCoordinates,
                            geodesic: true,
                            strokeColor: markers[i + 1].statusColor || '#000000',
                            strokeOpacity: 1.0,
                            strokeWeight: 2,
                            icons: [{
                                icon: lineSymbol,
                                offset: '100%'
                            }]
                        });

                        flightPaths.push(flightPath);

                    }

                    angular.forEach(flightPaths, function (flightPath) {

                        if (scope.connectPoints) {
                            flightPath.setMap(map);
                        } else {
                            flightPath.setMap(null);
                        }
                    })
                }

            }
        }
    }
} ])
.directive('logisticsShipmentsMap', ['$filter', function ($filter) {
    return {
        restrict: 'A',
        scope: {
            ngModel: '=',
            connectPoints: '=',
            showDetails: '='
        },
        link: function (scope, element, attrs, controller) {

            var shipment = [];

            var markersArray = [];

            var map;

            var flightPaths = [];

            var defaultCenterLatLng = { lng: 76.321, lat: 26.365 };

            scope.$watch('ngModel', function (newValue) {
                if (newValue) {
                    createMap();
                }
            }, true)

            scope.$watch('connectPoints', function (newValue) {
                if (newValue != undefined && map && shipment) {
                    setFlightPaths(map, shipment);
                }
            })

            function createMap() {

                var mapOptions = {
                    center: defaultCenterLatLng,
                    zoom: 4,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    mapTypeControl: false,
                    streetViewControl: false,
                    rotateControl: false
                };

                shipment = getShipmentMarkerCoordinates();

                if (shipment.length > 0 && shipment[0].markers.length > 0) {
                    mapOptions.center = shipment[0].markers[0].coordinates;
                }

                if (map) {
                    clearMap();
                    map.setCenter(mapOptions.center);
                } else {
                    map = new google.maps.Map(element[0], mapOptions);
                }

                setMarkers(map, shipment);

                if (scope.connectPoints) {
                    setFlightPaths(map, shipment);
                }

            }

            function clearMap() {
                if (markersArray.length > 0) {
                    for (var i = 0; i < markersArray.length; i++) {
                        markersArray[i].setMap(null);
                    }
                    markersArray = [];
                }
                if (flightPaths.length > 0) {
                    angular.forEach(flightPaths, function (flightPath) {
                        flightPath.setMap(null);
                    })
                    flightPaths = [];
                }
            }

            function getShipmentMarkerCoordinates() {
                var shipment = [];
                angular.forEach(scope.ngModel, function (model, index) {
                    shipment.push({
                        id: model.shipmentId,
                        markers: []
                    })
                    if (model.deliveryPoints && model.deliveryPoints.length > 0) {
                        angular.forEach(model.deliveryPoints, function (deliveryPoint) {
                            if (deliveryPoint.lat != undefined && deliveryPoint.lng != undefined &&
                                deliveryPoint.lat != '' && deliveryPoint.lng != '') {
                                shipment[index].markers.push({
                                    coordinates: {
                                        lat: parseFloat(deliveryPoint.lat),
                                        lng: parseFloat(deliveryPoint.lng)
                                    },
                                    title: deliveryPoint.locationName,
                                    statusColor: deliveryPoint.statusColor,
                                    status: deliveryPoint.statusName,
                                    estimatedDate: deliveryPoint.estimatedDate
                                })
                            }
                        })
                    }

                })
                return shipment;
            }

            function setMarkers(map, shipment) {

                var infowindow = new google.maps.InfoWindow({
                    content: ""
                });

                for (shipmentIndex = 0; shipmentIndex < shipment.length; shipmentIndex++) {

                    var shipmentObj = shipment[shipmentIndex];

                    for (i = 0; i < shipmentObj.markers.length; i++) {

                        var infoWindowHTML = '';

                        infoWindowHTML = '<div>' +
                                '<b> ' + shipmentObj.markers[i].title + ' </b> <br>' +
                                '<span style="font-size: 12px;">' + shipmentObj.markers[i].status + '</span> <br>' +
                                '<span style="font-size: 12px;">' + (shipmentObj.markers[i].estimatedDate ? $filter('date')(shipmentObj.markers[i].estimatedDate, 'dd-MMM-yyyy') : '') + '</span>' +
                            '</div>'

                        var marker = new google.maps.Marker({
                            position: shipmentObj.markers[i].coordinates,
                            map: map,
                            title: shipmentObj.markers[i].title,
                            content: infoWindowHTML
                        });

                        marker.addListener('click', function () {
                            if (scope.showDetails) {
                                infowindow.setContent(this.content);
                                infowindow.open(map, this);
                            }
                        });

                        markersArray.push(marker);
                    }
                }

            }

            function setFlightPaths(map, shipment) {

                if (flightPaths.length > 0) {
                    angular.forEach(flightPaths, function (flightPath) {
                        if (scope.connectPoints) {
                            flightPath.setMap(map);
                        } else {
                            flightPath.setMap(null);
                        }
                    })

                } else {
                    for (shipmentIndex = 0; shipmentIndex < shipment.length; shipmentIndex++) {
                        var shipmentObj = shipment[shipmentIndex]
                        for (i = 0; i < shipmentObj.markers.length - 1; i++) {

                            var flightPlanCoordinates = [shipmentObj.markers[i].coordinates, shipmentObj.markers[i + 1].coordinates]

                            var lineSymbol = {
                                path: google.maps.SymbolPath.FORWARD_OPEN_ARROW
                            };

                            var flightPath = new google.maps.Polyline({
                                path: flightPlanCoordinates,
                                geodesic: true,
                                strokeColor: shipmentObj.markers[i + 1].statusColor || '#000000',
                                strokeOpacity: 1.0,
                                strokeWeight: 2,
                                icons: [{
                                    icon: lineSymbol,
                                    offset: '100%'
                                }]
                            });

                            flightPaths.push(flightPath);

                        }
                    }

                    angular.forEach(flightPaths, function (flightPath) {
                        if (scope.connectPoints) {
                            flightPath.setMap(map);
                        } else {
                            flightPath.setMap(null);
                        }
                    })
                }

            }
        }
    }
} ])