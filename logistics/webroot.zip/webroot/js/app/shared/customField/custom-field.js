angular.module('customField', [])
.directive('customField', [
function () {
    return {
        restrict: 'A',
        scope: {
            customFields: '=',
            applyType: '='
        },
        templateUrl: 'js/app/shared/customField/views/customField.html',
        controller: ['$scope', 'INPUT_TYPE', 'CALENDER_DATE_OPT', 'CALENDER_FORMAT',
        function ($scope, INPUT_TYPE, CALENDER_DATE_OPT, CALENDER_FORMAT) {

            $scope.inputType = INPUT_TYPE;

            $scope.openCalendar = function ($event, calObj) {
                $event.preventDefault();
                $event.stopPropagation();
                calObj.openCalendar = !calObj.openCalendar;
            }

            $scope.format = CALENDER_FORMAT['dd-MM-yyyy'];

            $scope.dateOptions = CALENDER_DATE_OPT;

        } ]
    }
} ])